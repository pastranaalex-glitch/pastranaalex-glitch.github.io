@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0.."
if not exist "Android\app\src\main\java\es\bibliotecadeherramientas\sudokuvivo\SudokuLogic.java" (
 echo ERROR: faltan archivos del proyecto.
 pause
 exit /b 1
)
if not exist ".pruebas" mkdir ".pruebas"
set "JAVA_SOURCE=Android\app\src\main\java\es\bibliotecadeherramientas\sudokuvivo"
javac -encoding UTF-8 -d ".pruebas" "%JAVA_SOURCE%\PuzzleBank.java" "%JAVA_SOURCE%\SudokuLogic.java" "%JAVA_SOURCE%\GameState.java" "%JAVA_SOURCE%\PuzzleGenerator.java" "%JAVA_SOURCE%\AdventureProgress.java" "Herramientas\PruebaMotor.java" "Herramientas\PruebaAventura.java"
if errorlevel 1 goto :error
java -cp ".pruebas" PruebaMotor
if errorlevel 1 goto :error
java -cp ".pruebas" PruebaAventura
if errorlevel 1 goto :error
echo Comprobacion superada.
pause
exit /b 0
:error
echo Fallo en las pruebas. Necesitas el JDK de Android Studio.
pause
exit /b 1
