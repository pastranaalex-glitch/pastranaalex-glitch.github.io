package es.bibliotecadeherramientas.sudokuvivo;

import java.util.Random;

/** Crea tableros nuevos sin conexión y conserva el nivel lógico de cada patrón.
 *  Permutar bandas, filas, columnas y dígitos mantiene la solución única
 *  y las técnicas necesarias del tablero de origen.
 */
public final class PuzzleGenerator {
    private PuzzleGenerator() { }
    public static int[] create(int difficulty, long seed) {
        if (difficulty<0 || difficulty>2) throw new IllegalArgumentException("Dificultad inválida");
        Random rnd=new Random(seed ^ 0x6C8E9CF570932BD1L);
        int[] source=SudokuLogic.parse(PuzzleBank.get(difficulty,rnd.nextInt(PuzzleBank.PER_DIFFICULTY)));
        int[] rowOrder=permutation(rnd), columnOrder=permutation(rnd);
        int[] digitMap={0,1,2,3,4,5,6,7,8,9};
        for (int i=9;i>1;i--) {int j=1+rnd.nextInt(i);int temp=digitMap[i];digitMap[i]=digitMap[j];digitMap[j]=temp;}
        boolean swapAxes=rnd.nextBoolean();
        int[] output=new int[81];
        for (int r=0;r<9;r++) for (int c=0;c<9;c++) {
            int oldR=swapAxes?columnOrder[c]:rowOrder[r];
            int oldC=swapAxes?rowOrder[r]:columnOrder[c];
            output[r*9+c]=digitMap[source[oldR*9+oldC]];
        }
        return output;
    }
    private static int[] permutation(Random rnd) {
        int[] bands={0,1,2}; shuffle(bands,rnd);
        int[] result=new int[9];
        for(int b=0;b<3;b++) {
            int[] within={0,1,2}; shuffle(within,rnd);
            for(int i=0;i<3;i++)result[3*b+i]=bands[b]*3+within[i];
        }
        return result;
    }
    private static void shuffle(int[] a,Random rnd) {
        for(int i=a.length-1;i>0;i--) {int j=rnd.nextInt(i+1);int v=a[i];a[i]=a[j];a[j]=v;}
    }
}
