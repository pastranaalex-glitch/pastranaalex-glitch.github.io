package es.bibliotecadeherramientas.sudokuvivo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.View;

/** Imagen descubierta bloque a bloque; usa ilustraciones incluidas en la APK. */
public final class AdventureRevealView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    private Bitmap bitmap;
    private int mask;
    private final int dim;
    public AdventureRevealView(Context context,int imageId,int mask,int dim){
        super(context);this.mask=mask&511;this.dim=dim;
        bitmap=BitmapFactory.decodeResource(getResources(),imageId);
        setContentDescription("Imagen de la aventura: "+Integer.bitCount(this.mask)+" de 9 partes descubiertas");
    }
    public void setMask(int next){
        mask=next&511;
        setContentDescription("Imagen de la aventura: "+Integer.bitCount(mask)+" de 9 partes descubiertas");
        invalidate();
    }
    @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
        int w=MeasureSpec.getSize(widthMeasureSpec);
        if(w<=0)w=720;
        int h=Math.max(1,Math.round(w*480f/768f));
        setMeasuredDimension(w,h);
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        float w=getWidth(),h=getHeight();
        if(bitmap!=null){
            paint.setColor(0xffffffff);paint.setAlpha(255);
            canvas.drawBitmap(bitmap,new Rect(0,0,bitmap.getWidth(),bitmap.getHeight()),new RectF(0,0,w,h),paint);
        }else{canvas.drawColor(0xff263545);}
        paint.setStyle(Paint.Style.FILL);paint.setColor(dim);
        for(int i=0;i<9;i++){
            if((mask&(1<<i))!=0)continue;
            int row=i/3,col=i%3;
            float x0=w*col/3f,y0=h*row/3f,x1=w*(col+1)/3f,y1=h*(row+1)/3f;
            canvas.drawRect(x0,y0,x1,y1,paint);
        }
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(Math.max(1f,getResources().getDisplayMetrics().density));
        paint.setColor(0x88FFFFFF);
        for(int i=1;i<=2;i++){
            canvas.drawLine(w*i/3f,0,w*i/3f,h,paint);
            canvas.drawLine(0,h*i/3f,w,h*i/3f,paint);
        }
        paint.setStyle(Paint.Style.FILL);
    }
}
