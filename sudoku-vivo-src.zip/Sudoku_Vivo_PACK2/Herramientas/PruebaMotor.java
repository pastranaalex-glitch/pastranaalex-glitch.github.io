import es.bibliotecadeherramientas.sudokuvivo.GameState;
import es.bibliotecadeherramientas.sudokuvivo.PuzzleBank;
import es.bibliotecadeherramientas.sudokuvivo.PuzzleGenerator;
import es.bibliotecadeherramientas.sudokuvivo.SudokuLogic;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Pruebas en Windows sin Android Studio: 36 tableros originales + 900 generados. */
public final class PruebaMotor {
    private static void check(boolean condition,String msg){if(!condition)throw new AssertionError(msg);}
    private static void checkPuzzle(int[] puzzle,int d,String tag){
        check(puzzle.length==81,"longitud "+tag);
        check(SudokuLogic.countSolutions(puzzle,2)==1,"no tiene solución única "+tag);
        int[] solved=SudokuLogic.solve(puzzle);
        for(int p=0;p<81;p++){
            check(solved[p]>=1&&solved[p]<=9,"solución incompleta "+tag);
            check(SudokuLogic.allowed(solved,p,solved[p]),"violación de Sudoku "+tag);
            if(puzzle[p]!=0)check(solved[p]==puzzle[p],"pista incorrecta "+tag);
        }
        int clues=0;for(int n:puzzle)if(n!=0)clues++;
        check(clues>=17&&clues<81,"tablero inválido: "+tag);
        check(Arrays.equals(puzzle,SudokuLogic.parse(SudokuLogic.encode(puzzle))),"codificación "+tag);
    }
    public static void main(String[] args){
        Set<String> examples=new HashSet<>(),generated=new HashSet<>();
        int total=0;
        for(int d=0;d<3;d++)for(int i=0;i<PuzzleBank.PER_DIFFICULTY;i++){
            int[] start=SudokuLogic.parse(PuzzleBank.get(d,i));
            check(examples.add(SudokuLogic.encode(start)),"colección inicial repetida");
            checkPuzzle(start,d,"original "+d+"/"+i);
            GameState state=new GameState(d,i);
            SudokuLogic.Hint hint=SudokuLogic.findHint(start,state.solution);
            check(hint!=null&&hint.number==state.solution[hint.position],"pista incorrecta");
            check(state.change(hint.position,hint.number,false),"cambio número");
            check(state.undo()&&state.cells[hint.position]==0,"deshacer");
            check(state.redo()&&state.cells[hint.position]==hint.number,"rehacer");
            check(state.undo(),"volver a deshacer");
            check(state.change(hint.position,3,true),"escribir nota");
            check(state.undo()&&state.notes[hint.position]==0,"deshacer nota");
            total++;
        }
        for(int d=0;d<3;d++)for(int i=0;i<300;i++){
            long seed=i*1618033989L+d*104729L+123456789L;
            int[] first=PuzzleGenerator.create(d,seed);
            int[] again=PuzzleGenerator.create(d,seed);
            check(Arrays.equals(first,again),"generación no reproducible");
            check(generated.add(SudokuLogic.encode(first)),"generado repetido");
            checkPuzzle(first,d,"generado "+d+"/"+i);
            GameState state=GameState.generated(d,seed);
            check(Arrays.equals(state.original,first),"semilla distinta");
            total++;
        }
        // Un grupo de notas automáticas es una sola operación de deshacer.
        GameState auto=GameState.generated(0,916L);
        int changed=auto.fillAutomaticNotes(false);
        check(changed>0,"candidatos automáticos vacíos");
        for(int p=0;p<81;p++)if(auto.cells[p]==0)
            check(auto.notes[p]==SudokuLogic.candidateMask(auto.cells,p),"notas automáticas erróneas");
        int[] pre=auto.notes.clone();
        check(auto.undo(),"deshacer todas las notas");
        for(int notes:auto.notes)check(notes==0,"notas restantes tras deshacer");
        check(auto.redo()&&Arrays.equals(pre,auto.notes),"rehacer todas las notas");
        int pos=-1;for(int p=0;p<81;p++)if(auto.cells[p]==0){pos=p;break;}
        int n=auto.solution[pos];
        check(auto.change(pos,n,false,true),"introducir número correcto");
        for(int p=0;p<81;p++)if(p!=pos&&auto.cells[p]==0&&
            (p/9==pos/9||p%9==pos%9||(p/27==pos/27&&(p%9)/3==(pos%9)/3)))
            check((auto.notes[p]&(1<<n))==0,"falta limpiar nota descartada");
        check(auto.undo(),"deshacer introducción y notas asociadas");
        check(auto.cells[pos]==0&&Arrays.equals(pre,auto.notes),"deshacer no restauró notas");
        check(auto.redo()&&auto.cells[pos]==n,"rehacer número y notas");
        check(auto.clearNotes()>0,"limpiar notas");
        check(auto.undo(),"deshacer borrado completo de notas");
        check(SudokuLogic.countSolutions(new int[81],2)==2,"tablero vacío con varias soluciones");
        System.out.println("CORRECTO: "+total+" sudokus (36 originales + 900 generados) con solución única.");
        System.out.println("CORRECTO: reproducibilidad por semilla, solución, notas automáticas, limpieza, deshacer y rehacer.");
    }
}
