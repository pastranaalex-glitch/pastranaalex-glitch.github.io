﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$project = Join-Path $root 'Android'
$toolFolder = Join-Path $root '.herramientas'
$log = Join-Path $root 'registro_compilacion.txt'
$apk = Join-Path $root 'SudokuVivo_PACK4_Pruebas.apk'
# Java puede anunciar JAVA_TOOL_OPTIONS en stderr: PowerShell 5.1 lo confunde con un error.
# Este valor no es necesario; lo limpiamos solo para el proceso de compilacion.
Remove-Item Env:JAVA_TOOL_OPTIONS -ErrorAction SilentlyContinue
# Reiniciar el informe para que no aparezcan errores de ejecuciones anteriores.
Set-Content -Path $log -Value 'Sudoku Vivo PACK 4 - Registro de compilacion' -Encoding UTF8
function Escribir([string]$msg) { Write-Host $msg }
function Fallar([string]$msg) { throw $msg }
try {
    Escribir '1/4 Comprobando Java...'
    $jbr = 'C:\Program Files\Android\Android Studio\jbr'
    if ((Test-Path (Join-Path $jbr 'bin\java.exe'))) {
        $env:JAVA_HOME = $jbr
        $env:PATH = (Join-Path $jbr 'bin') + ';' + $env:PATH
    }
    if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
        $java = Join-Path $env:JAVA_HOME 'bin\java.exe'
    } else {
        $javaCmd = Get-Command java -ErrorAction SilentlyContinue
        if (-not $javaCmd) { Fallar 'No se ha encontrado Java. Instala Android Studio con su JDK incluido (JDK 17 o superior).' }
        $java = $javaCmd.Source
    }
    # Los programas Java escriben versiones y avisos en stderr incluso sin fallar.
    # En Windows PowerShell 5.1 con Stop, redirigir stderr puede abortar por error.
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $java -version 2>&1 | ForEach-Object { Write-Host ([string]$_) }
        $javaExitCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    if ($javaExitCode -ne 0) { Fallar 'No se ha podido iniciar Java.' }

    Escribir '2/4 Buscando Android SDK...'
    $candidates = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, (Join-Path $env:LOCALAPPDATA 'Android\Sdk'))
    $sdk = $null
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path (Join-Path $candidate 'platforms\android-35\android.jar'))) { $sdk=$candidate;break }
    }
    if (-not $sdk) { Fallar 'Falta Android SDK Platform 35. Abre Android Studio > SDK Manager > SDK Platforms e instala Android API 35.' }
    $env:ANDROID_HOME = $sdk
    $env:ANDROID_SDK_ROOT = $sdk
    Escribir "SDK: $sdk"

    Escribir '3/4 Localizando Gradle 8.7...'
    $gradle = $null
    $installed = Get-Command gradle -ErrorAction SilentlyContinue
    if ($installed) { $gradle = $installed.Source }
    else {
        $gradleDir = Join-Path $toolFolder 'gradle-8.7'
        $gradle = Join-Path $gradleDir 'bin\gradle.bat'
        if (-not (Test-Path $gradle)) {
            New-Item -ItemType Directory -Force -Path $toolFolder | Out-Null
            $zip = Join-Path $toolFolder 'gradle-8.7-bin.zip'
            Escribir 'Descargando Gradle desde services.gradle.org (solo la primera vez)...'
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.7-bin.zip' -OutFile $zip -UseBasicParsing
            Expand-Archive -LiteralPath $zip -DestinationPath $toolFolder -Force
            Remove-Item $zip -Force
        }
    }
    if (-not (Test-Path $gradle)) { Fallar 'No se encontró Gradle. Si estás sin Internet, usa el Gradle instalado con Android Studio.' }
    Escribir "Gradle: $gradle"

    Escribir '4/4 Compilando APK de pruebas...'
    Push-Location $project
    try {
        # Evitar que el stderr informativo de Gradle se convierta en una excepcion.
        $oldPreference = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try {
            & $gradle --no-daemon --stacktrace :app:assembleDebug 2>&1 | Tee-Object -FilePath $log -Append
            $gradleExitCode = $LASTEXITCODE
        } finally { $ErrorActionPreference = $oldPreference }
        if ($gradleExitCode -ne 0) { Fallar "Fallo Gradle (codigo $gradleExitCode). Revisa $log" }
    } finally { Pop-Location }
    $source = Join-Path $project 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path $source)) { Fallar 'La compilación terminó pero no se encontró el APK.' }
    Copy-Item -LiteralPath $source -Destination $apk -Force
    Escribir "APK: $apk"
    Escribir 'ATENCION: versión DEBUG, solo para pruebas. No distribuir como versión definitiva.'
    exit 0
}
catch {
    $msg = $_.Exception.Message
    Write-Host "`nERROR: $msg" -ForegroundColor Red
    Add-Content -Path $log -Value "ERROR: $msg" -Encoding UTF8
    exit 1
}
