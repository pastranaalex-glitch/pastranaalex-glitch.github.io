import es.bibliotecadeherramientas.sudokuvivo.AdventureProgress;
import es.bibliotecadeherramientas.sudokuvivo.GameState;
import es.bibliotecadeherramientas.sudokuvivo.SudokuLogic;

public final class PruebaAventura {
    private static void ok(boolean v,String msg){if(!v)throw new AssertionError(msg);}
    public static void main(String[] args){
        int completed=0;
        ok(AdventureProgress.unlocked(completed,0),"nivel 1 debe estar abierto");
        ok(!AdventureProgress.unlocked(completed,1),"nivel 2 debe estar cerrado");
        for(int level=0;level<AdventureProgress.LEVEL_COUNT;level++){
            ok(AdventureProgress.unlocked(completed,level),"nivel bloqueado "+level);
            GameState a=GameState.generated(AdventureProgress.difficulty(level),AdventureProgress.seed(level));
            GameState b=GameState.generated(AdventureProgress.difficulty(level),AdventureProgress.seed(level));
            ok(SudokuLogic.encode(a.original).equals(SudokuLogic.encode(b.original)),"nivel no reproducible");
            ok(SudokuLogic.countSolutions(a.original,2)==1,"Sudoku con mas de una solucion en nivel "+level);
            int initial=AdventureProgress.revealedMask(a);
            ok(initial>=0&&initial<=511,"mascara invalida");
            // Completar un bloque con la solución real revela exactamente ese bloque.
            for(int i=0;i<9;i++) {
                int r=i/3,c=i%3,p=r*9+c;
                a.cells[p]=a.solution[p];
            }
            ok((AdventureProgress.revealedMask(a)&1)!=0,"no se revela el primer bloque");
            // Un error no debe revelar una región ni contar como acierto.
            a.cells[0]=a.solution[0]==9?1:a.solution[0]+1;
            ok((AdventureProgress.revealedMask(a)&1)==0,"se revelo con un error");
            System.arraycopy(a.solution,0,a.cells,0,81);
            ok(AdventureProgress.revealedMask(a)==511,"no se revela todo al completar");
            ok(a.solved(),"no detecta victoria");
            completed=AdventureProgress.complete(completed,level);
            ok(AdventureProgress.completed(completed,level),"no guarda completo");
            ok(AdventureProgress.count(completed)==level+1,"contador incorrecto");
            if(level<8)ok(AdventureProgress.unlocked(completed,level+1),"no desbloquea el siguiente");
        }
        ok(completed==511,"coleccion incompleta");
        ok(!AdventureProgress.validLevel(9),"indice no valido aceptado");
        System.out.println("CORRECTO: 9 niveles, 9 soluciones únicas, revelado 3x3, errores, desbloqueos y colección.");
    }
}
