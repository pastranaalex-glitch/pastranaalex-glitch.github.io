package es.bibliotecadeherramientas.sudokuvivo;

/** Modelo de niveles de Aventura: independiente de Android y comprobable en Java. */
public final class AdventureProgress {
    private AdventureProgress() { }
    public static final int LEVEL_COUNT=9;
    public static final String[] WORLD_NAMES={"Naturaleza", "Ciudades", "Universo"};
    public static final String[] WORLD_DETAILS={
        "Horizontes, agua y montañas", "Arquitectura y luces urbanas", "Estrellas y paisajes del cosmos"
    };
    public static final String[] LEVEL_TITLES={
        "Lago al amanecer", "Montañas en la niebla", "Costa al atardecer",
        "Ciudad histórica", "Puente al anochecer", "Horizonte nocturno",
        "Cielo estrellado", "El planeta azul", "Nebulosa violeta"
    };
    public static boolean validLevel(int index){return index>=0&&index<LEVEL_COUNT;}
    public static int world(int index){if(!validLevel(index))throw new IllegalArgumentException("Nivel inexistente");return index/3;}
    public static int difficulty(int index){return world(index);}
    public static long seed(int index){
        if(!validLevel(index))throw new IllegalArgumentException("Nivel inexistente");
        return 0x71239607A14E63D9L ^ (0x9E3779B97F4A7C15L * (index+1L));
    }
    public static int sanitizedMask(int mask){return mask&((1<<LEVEL_COUNT)-1);}
    public static int count(int mask){return Integer.bitCount(sanitizedMask(mask));}
    public static boolean completed(int mask,int index){return validLevel(index)&&(sanitizedMask(mask)&(1<<index))!=0;}
    /** La Aventura desbloquea niveles consecutivos, sin saltarse los anteriores. */
    public static boolean unlocked(int mask,int index){
        if(!validLevel(index))return false;
        int previous=(1<<index)-1;
        return (sanitizedMask(mask)&previous)==previous;
    }
    public static int complete(int mask,int index){
        if(!unlocked(mask,index))throw new IllegalArgumentException("Nivel bloqueado");
        return sanitizedMask(mask)|(1<<index);
    }
    public static int nextUnfinished(int mask){
        for(int i=0;i<LEVEL_COUNT;i++)if(!completed(mask,i))return i;
        return LEVEL_COUNT-1;
    }
    /** Cuántos bloques 3x3 contienen sus nueve soluciones correctas. */
    public static int revealedMask(GameState state){
        if(state==null)return 0;
        int mask=0;
        for(int block=0;block<9;block++){
            int r=(block/3)*3,c=(block%3)*3;
            boolean all=true;
            for(int dr=0;dr<3&&all;dr++)for(int dc=0;dc<3;dc++){
                int p=(r+dr)*9+(c+dc);
                if(state.cells[p]==0||state.cells[p]!=state.solution[p]){all=false;break;}
            }
            if(all)mask|=1<<block;
        }
        return mask;
    }
}
