@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Sudoku Vivo - Compilacion PACK 4
color 0B
echo ======================================================
echo       SUDOKU VIVO - PACK 4 - ANDROID
 echo ======================================================
echo.
echo Compilando una APK de pruebas sin modificar tus firmas.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Herramientas\Compilar.ps1"
set "ERROR_CODE=%ERRORLEVEL%"
echo.
if not "%ERROR_CODE%"=="0" (
 echo [ERROR] No se ha podido generar la APK.
 echo Comprueba el mensaje anterior y el log de compilacion.
) else (
 echo [OK] APK generada: SudokuVivo_PACK4_Pruebas.apk
)
echo.
pause
exit /b %ERROR_CODE%
