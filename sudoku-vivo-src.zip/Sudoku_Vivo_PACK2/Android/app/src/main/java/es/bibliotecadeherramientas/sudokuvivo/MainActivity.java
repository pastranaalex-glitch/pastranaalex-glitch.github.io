package es.bibliotecadeherramientas.sudokuvivo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Sudoku Vivo Pack 2: Android nativo, sin cuentas, Internet ni dependencias externas. */
public final class MainActivity extends Activity {
    private static final String PREFS="sudoku_vivo_local_v1";
    private static final String SAVE_KEY="partida_guardada";
    private static final int HOME=0,GAME=1,LESSONS=2,ADVENTURE=3,OPTIONS=4;
    private SharedPreferences prefs;
    private ThemePalette colors;
    private GameState game;
    private int screen=HOME,selectedCell=-1,lessonStep=0;
    private boolean noteMode=false,showErrors=true,resumed=false,lessonCorrect=false;
    private ScrollView scroll;
    private LinearLayout page;
    private SudokuBoardView boardView;
    private TextView gameInfo,noteAction,lessonFeedback,lessonNext,lessonTarget,candidateInfo;
    private boolean cleanRelatedNotes=true,showCandidates=true,largeNumbers=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable clock=new Runnable(){
        @Override public void run(){
            if(resumed){
                if(screen==GAME&&game!=null&&!game.solved()){
                    game.seconds++;
                    refreshGameInfo();
                    if(game.seconds%5==0)persistGame();
                }
                handler.postDelayed(this,1000);
            }
        }
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        colors=ThemePalette.of(prefs.getInt("color_theme",0));
        showErrors=prefs.getBoolean("show_errors",true);
        cleanRelatedNotes=prefs.getBoolean("clean_related_notes",true);
        showCandidates=prefs.getBoolean("show_candidates",true);
        largeNumbers=prefs.getBoolean("large_numbers",false);
        restoreGame();
        showHome();
    }
    @Override protected void onResume(){super.onResume();resumed=true;handler.removeCallbacks(clock);handler.postDelayed(clock,1000);}
    @Override protected void onPause(){resumed=false;handler.removeCallbacks(clock);persistGame();super.onPause();}
    @Override public void onBackPressed(){
        if(screen==HOME){super.onBackPressed();return;}
        persistGame();showHome();
    }

    private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
    private GradientDrawable background(int color,int radius,int stroke){
        GradientDrawable drawable=new GradientDrawable();
        drawable.setColor(color);drawable.setCornerRadius(dp(radius));
        if(stroke!=0)drawable.setStroke(dp(1),stroke);
        return drawable;
    }
    private TextView text(String content,int sp,boolean bold,int color){
        TextView view=new TextView(this);
        view.setText(content);view.setTextColor(color);view.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        view.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        view.setIncludeFontPadding(true);view.setLineSpacing(dp(2),1.06f);
        return view;
    }
    private TextView button(String label,boolean prominent){
        TextView button=text(label,15,true,prominent?colors.surface:colors.ink);
        button.setGravity(Gravity.CENTER);button.setPadding(dp(13),dp(12),dp(13),dp(12));
        button.setMinHeight(dp(49));
        button.setBackground(background(prominent?colors.accent:colors.button,13,prominent?0:colors.border));
        button.setClickable(true);button.setFocusable(true);
        return button;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void add(LinearLayout parent,View view,int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(view,p);
    }
    private void spaced(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void initScreen(int kind){
        screen=kind;boardView=null;gameInfo=null;noteAction=null;candidateInfo=null;
        colors=ThemePalette.of(prefs.getInt("color_theme",0));
        getWindow().setStatusBarColor(colors.bg);getWindow().setNavigationBarColor(colors.bg);
        boolean light=prefs.getInt("color_theme",0)!=1;
        int flags=getWindow().getDecorView().getSystemUiVisibility();
        if(light)flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        else flags&=~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setSystemUiVisibility(flags);
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(colors.bg);
        scroll.setClipToPadding(false);
        int hor=dp(15),vertical=dp(13);
        scroll.setPadding(hor,vertical,hor,dp(22));
        scroll.setOnApplyWindowInsetsListener((v,insets)->{
            // Los teléfonos con interfaz borde a borde no deben tapar ningún control.
            int top=insets.getSystemWindowInsetTop(),bottom=insets.getSystemWindowInsetBottom();
            v.setPadding(hor,Math.max(vertical,top+dp(7)),hor,Math.max(dp(22),bottom+dp(7)));
            return insets;
        });
        page=column();page.setPadding(dp(2),dp(6),dp(2),dp(8));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));
        setContentView(scroll);
    }
    private void heading(String eyebrow,String headline,String details){
        if(eyebrow!=null)add(page,text(eyebrow.toUpperCase(Locale.ROOT),11,true,colors.accent),4);
        if(headline!=null)add(page,text(headline,28,true,colors.ink),8);
        if(details!=null)add(page,text(details,14,false,colors.muted),7);
    }
    private void card(String title,String body,String action,boolean active,Runnable run){
        LinearLayout box=column();box.setPadding(dp(17),dp(15),dp(17),dp(15));
        box.setBackground(background(colors.surface,18,colors.border));
        add(box,text(title,19,true,colors.ink),0);
        add(box,text(body,14,false,colors.muted),8);
        if(action!=null){
            TextView link=button(action,active);
            link.setEnabled(active);link.setAlpha(active?1f:.5f);
            add(box,link,12);
            if(active&&run!=null)link.setOnClickListener(v->run.run());
        }
        add(page,box,13);
    }
    private void topBar(String title,Runnable back){
        LinearLayout bar=row();
        TextView go=button("‹",false);go.setTextSize(26);go.setMinWidth(dp(52));
        bar.addView(go,new LinearLayout.LayoutParams(dp(52),dp(49)));
        go.setContentDescription("Volver a inicio");go.setOnClickListener(v->back.run());
        TextView name=text(title,19,true,colors.ink);name.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1f);np.leftMargin=dp(13);
        bar.addView(name,np);add(page,bar,2);
    }
    private void showHome(){
        initScreen(HOME);
        heading("Biblioteca de herramientas","Sudoku Vivo","Aprende, resuelve y descubre. Un juego de lógica pensado para disfrutar a tu ritmo.");
        if(game!=null){
            card("Continuar partida",PuzzleBank.DIFFICULTIES[game.difficulty]+" · "+(game.generated?"Sudoku generado":"Colección · Tablero "+(game.index+1))+" · "+game.filled()+"/81 casillas completas","Seguir jugando",true,()->showGame());
        }
        card("Sudoku clásico sin límites","Nuevos sudokus con solución única en tres dificultades. Notas inteligentes, pistas razonadas y guardado automático.","Nuevo Sudoku",true,()->chooseNewGame(true));
        card("Colección inicial","Si lo prefieres, también puedes jugar los 36 tableros originales, conservados del primer pack.","Explorar colección",true,()->chooseNewGame(false));
        card("Escuela de Sudoku","Aprende las reglas desde cero. Ejercicios sencillos y explicaciones, sin cronómetro ni presión.","Empezar a aprender",true,()->{lessonStep=Math.min(prefs.getInt("lesson_progress",0),5);lessonCorrect=false;showLessons();});
        card("Aventura visual","Explorarás mundos y descubrirás fotografías al resolver sudokus. Esta modalidad se incorporará en próximos packs.","Conocer la aventura",true,this::showAdventure);
        TextView settings=button("Colores y preferencias",false);add(page,settings,13);settings.setOnClickListener(v->showOptions());
        TextView footer=text("Versión 0.2.0 · Pack 2 · Sin anuncios · Sin conexión necesaria",12,false,colors.muted);
        footer.setGravity(Gravity.CENTER);add(page,footer,20);
    }
    private void chooseNewGame(){chooseNewGame(true);}
    private void chooseNewGame(boolean generated){
        new AlertDialog.Builder(this).setTitle(generated?"Elegir dificultad · Sudoku nuevo":"Elegir dificultad · Colección")
          .setItems(new String[]{"Fácil · para empezar","Media · un poco más de lógica","Difícil · mayor desafío"},(dialog,which)->{
            Runnable start=()->{
                int index=prefs.getInt("completed_"+which,0)%PuzzleBank.PER_DIFFICULTY;
                if(generated){
                    // Evita repetir la semilla si se crean partidas con pocos milisegundos de diferencia.
                    long sequence=prefs.getLong("generated_sequence",0L)+1L;
                    prefs.edit().putLong("generated_sequence",sequence).apply();
                    long seed=System.nanoTime()^(sequence*0x9E3779B97F4A7C15L);
                    game=GameState.generated(which,seed);
                }else game=new GameState(which,index);
                selectedCell=firstBlank();noteMode=false;persistGame();showGame();
            };
            if(game!=null&&!game.solved())new AlertDialog.Builder(this).setTitle("¿Empezar otra partida?").setMessage("Se reemplazará la partida que tienes a medias. Si prefieres, vuelve y pulsa «Continuar partida».").setNegativeButton("Cancelar",null).setPositiveButton("Nueva partida",(d,w)->start.run()).show();
            else start.run();
        }).show();
    }
    private int firstBlank(){if(game==null)return -1;for(int i=0;i<81;i++)if(!game.locked(i))return i;return -1;}
    private void showGame(){
        if(game==null){showHome();return;}
        initScreen(GAME);
        topBar("Sudoku Vivo",()->{persistGame();showHome();});
        LinearLayout header=row();
        TextView meta=text(PuzzleBank.DIFFICULTIES[game.difficulty]+" · "+(game.generated?"Sudoku nuevo":"Colección "+(game.index+1)+"/12"),15,true,colors.ink);
        header.addView(meta,new LinearLayout.LayoutParams(0,-2,1f));
        TextView palette=button("◐ Tema",false);palette.setTextSize(13);
        header.addView(palette,new LinearLayout.LayoutParams(-2,dp(43)));
        palette.setOnClickListener(v->pickTheme(()->showGame()));
        add(page,header,14);
        gameInfo=text("",12,false,colors.muted);add(page,gameInfo,8);
        boardView=new SudokuBoardView(this);
        boardView.setGame(game);boardView.setTheme(colors);boardView.setRevealErrors(showErrors);
        boardView.setLargeNumbers(largeNumbers);
        if(selectedCell<0||selectedCell>80)selectedCell=firstBlank();
        boardView.setSelected(selectedCell);
        boardView.setOnCellTap(pos->{selectedCell=pos;boardView.setSelected(pos);boardView.setHint(-1);refreshCandidateInfo();});
        LinearLayout boardWrap=column();boardWrap.setBackground(background(colors.surface,12,colors.border));
        boardWrap.setPadding(dp(3),dp(3),dp(3),dp(3));
        boardWrap.addView(boardView,new LinearLayout.LayoutParams(-1,-2));
        add(page,boardWrap,12);
        candidateInfo=text("",12,false,colors.muted);add(page,candidateInfo,8);
        LinearLayout numbers=row();numbers.setGravity(Gravity.CENTER);
        for(int number=1;number<=9;number++){
            final int n=number;
            TextView key=button(String.valueOf(n),false);key.setTextSize(20);key.setMinHeight(dp(48));key.setPadding(0,0,0,0);
            LinearLayout.LayoutParams kp=new LinearLayout.LayoutParams(0,dp(49),1f);
            kp.setMargins(dp(1),0,dp(1),0);
            numbers.addView(key,kp);key.setOnClickListener(v->putNumber(n));
        }
        add(page,numbers,14);
        LinearLayout actions=row();
        String[] labels={"↶\nDeshacer","✎\nNotas","⌫\nBorrar","?\nPista"};
        for(int i=0;i<labels.length;i++){
            final int action=i;
            TextView item=button(labels[i],false);
            item.setTextSize(12);item.setPadding(dp(3),dp(7),dp(3),dp(7));
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(54),1f);
            ap.setMargins(dp(3),0,dp(3),0);
            actions.addView(item,ap);
            if(i==1)noteAction=item;
            item.setOnClickListener(v->{
                switch(action){
                    case 0: if(game.undo()){gameChanged();}else toast("No hay cambios para deshacer");break;
                    case 1: noteMode=!noteMode;styleNoteButton();break;
                    case 2: putNumber(0);break;
                    case 3: requestHint();break;
                    default:break;
                }
            });
        }
        add(page,actions,12);
        LinearLayout noteTools=row();
        TextView automatic=button("✎  Notas posibles",false);
        TextView clear=button("Limpiar notas",false);
        TextView redo=button("↷  Rehacer",false);
        for(TextView tool:new TextView[]{automatic,clear,redo}){
            tool.setTextSize(12);tool.setPadding(dp(4),dp(9),dp(4),dp(9));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1f);p.setMargins(dp(2),0,dp(2),0);
            noteTools.addView(tool,p);
        }
        automatic.setOnClickListener(v->{
            int changed=game.fillAutomaticNotes(false);if(changed>0){gameChanged();toast("Notas calculadas en "+changed+" casillas");}
            else toast("Las notas ya están actualizadas");
        });
        clear.setOnClickListener(v->{int count=game.clearNotes();if(count>0){gameChanged();toast("Notas borradas");}else toast("No hay notas que borrar");});
        redo.setOnClickListener(v->{if(game.redo())gameChanged();else toast("No hay cambios para rehacer");});
        add(page,noteTools,8);
        TextView tip=text("Toca una casilla y elige un número. Las notas posibles se calculan a partir de las reglas, sin mostrarte la solución. Puedes continuar tu partida en cualquier momento.",12,false,colors.muted);
        add(page,tip,13);
        styleNoteButton();refreshGameInfo();refreshCandidateInfo();
    }
    private void styleNoteButton(){
        if(noteAction==null)return;
        noteAction.setBackground(background(noteMode?colors.accent:colors.button,13,noteMode?0:colors.border));
        noteAction.setTextColor(noteMode?colors.surface:colors.ink);
        noteAction.setContentDescription(noteMode?"Modo notas activado":"Modo notas desactivado");
    }
    private void refreshGameInfo(){
        if(gameInfo==null||game==null)return;
        int secs=game.seconds;
        String time=prefs.getBoolean("show_timer",true)?String.format(Locale.getDefault(),"%02d:%02d  ·  ",secs/60,secs%60):"";
        gameInfo.setText(time+game.filled()+" de 81 casillas  ·  "+game.hints+" pistas  ·  "+game.mistakes+" intentos erróneos");
    }
    private void gameChanged(){
        if(boardView!=null){boardView.setHint(-1);boardView.invalidate();}
        persistGame();refreshGameInfo();refreshCandidateInfo();
    }
    private void refreshCandidateInfo(){
        if(candidateInfo==null||game==null)return;
        if(selectedCell<0||selectedCell>=81){candidateInfo.setText("Selecciona una casilla del tablero.");return;}
        String pos="Fila "+(selectedCell/9+1)+", columna "+(selectedCell%9+1);
        if(game.locked(selectedCell)) {candidateInfo.setText(pos+" · Número fijo");return;}
        if(game.cells[selectedCell]!=0) {candidateInfo.setText(pos+" · Valor introducido: "+game.cells[selectedCell]);return;}
        if(!showCandidates){candidateInfo.setText(pos+" · Casilla vacía");return;}
        int mask=SudokuLogic.candidateMask(game.cells,selectedCell);
        StringBuilder opts=new StringBuilder();
        for(int n=1;n<=9;n++)if((mask&(1<<n))!=0){if(opts.length()>0)opts.append(", ");opts.append(n);}
        candidateInfo.setText(pos+" · Posibles: "+(opts.length()==0?"ninguno (revisa tus números)":opts.toString()));
    }
    private void putNumber(int n){
        if(game==null||boardView==null)return;
        if(selectedCell<0){toast("Selecciona una casilla");return;}
        if(game.locked(selectedCell)){toast("Este número es una pista fija del tablero");return;}
        if(game.change(selectedCell,n,noteMode,cleanRelatedNotes)){
            if(!noteMode&&n>0&&game.cells[selectedCell]!=game.solution[selectedCell])game.mistakes++;
            gameChanged();
            if(game.solved())finishGame();
        }
    }
    private void requestHint(){
        if(game==null)return;
        for(int i=0;i<81;i++) {
            if(game.cells[i]!=0&&game.cells[i]!=game.solution[i]){
                new AlertDialog.Builder(this).setTitle("Revisa el tablero").setMessage("Hay un número que todavía no encaja en la solución. Corrígelo antes de solicitar una pista lógica.").setPositiveButton("Entendido",null).show();
                return;
            }
        }
        SudokuLogic.Hint hint=SudokuLogic.findHint(game.cells,game.solution);
        if(hint==null){toast("¡Tablero completado!");return;}
        selectedCell=hint.position;boardView.setSelected(hint.position);boardView.setHint(hint.position);
        int row=hint.position/9+1,col=hint.position%9+1;
        String where="Fila "+row+", columna "+col+".\n\n"+hint.explanation;
        new AlertDialog.Builder(this).setTitle(hint.isDirect?"Ayuda avanzada":"Pista de lógica")
            .setMessage(where+"\n\n¿Quieres colocar el número o prefieres intentarlo tú?")
            .setNegativeButton("Intentarlo yo",null)
            .setPositiveButton("Colocar "+hint.number,(dialog,which)->{
                if(game==null)return;
                if(game.change(hint.position,hint.number,false)){
                    game.hints++;gameChanged();
                    if(game.solved())finishGame();
                }
            }).show();
    }
    private void finishGame(){
        if(game==null)return;
        final int diff=game.difficulty,index=game.index,seconds=game.seconds,hints=game.hints;
        final boolean generated=game.generated;
        String counter=generated?"completed_generated_"+diff:"completed_"+diff;
        prefs.edit().putInt(counter,prefs.getInt(counter,0)+1).remove(SAVE_KEY).apply();
        game=null; // Nunca restaurar como "partida pendiente" un tablero acabado.
        new AlertDialog.Builder(this).setTitle("¡Sudoku completado!")
            .setMessage("Has completado "+(generated?"un Sudoku nuevo":"el tablero "+(index+1))+" en "+String.format(Locale.getDefault(),"%02d:%02d",seconds/60,seconds%60)+".\nPistas aplicadas: "+hints+".\n\nPuedes seguir practicando a tu ritmo.")
            .setCancelable(false)
            .setNegativeButton("Volver al inicio",(d,w)->showHome())
            .setPositiveButton("Siguiente tablero",(d,w)->{
                if(generated){
                    long sequence=prefs.getLong("generated_sequence",0L)+1L;
                    prefs.edit().putLong("generated_sequence",sequence).apply();
                    game=GameState.generated(diff,System.nanoTime()^(sequence*0x9E3779B97F4A7C15L));
                }else game=new GameState(diff,(index+1)%PuzzleBank.PER_DIFFICULTY);
                selectedCell=firstBlank();noteMode=false;persistGame();showGame();
            }).show();
    }
    private void showAdventure(){
        initScreen(ADVENTURE);topBar("Aventura visual",this::showHome);
        heading("Próxima modalidad","Explora y descubre","Un viaje por mundos visuales, unido a tus progresos resolviendo sudokus.");
        card("Paisajes naturales","Cada región de 3×3 resuelta revelará parte de una imagen. Al acabar el tablero, podrás contemplarla completa.",null,false,null);
        card("Ciudades y monumentos","Los niveles te permitirán recorrer nuevas ubicaciones y guardar tus fotografías descubiertas en una colección.",null,false,null);
        card("Universo y ciencia","Habrá nuevos capítulos con imágenes de distintas temáticas. Sin premios que dependan de pagos o conexiones.",null,false,null);
        TextView footer=text("Esta función se está preparando. Mientras tanto, puedes resolver sudokus nuevos y aprender en la Escuela.",13,false,colors.muted);
        add(page,footer,16);
    }
    private void showOptions(){
        initScreen(OPTIONS);topBar("Personalización",this::showHome);
        heading(null,"A tu gusto","Elige los colores que prefieras. Siempre mantendremos un tablero claro y fácil de leer.");
        TextView theme=button("Tema actual: "+colors.name+"  ›",false);
        add(page,theme,18);theme.setOnClickListener(v->pickTheme(this::showOptions));
        TextView errors=button("Marcar números incorrectos: "+(showErrors?"Sí":"No"),false);
        add(page,errors,13);
        errors.setOnClickListener(v->{showErrors=!showErrors;prefs.edit().putBoolean("show_errors",showErrors).apply();showOptions();});
        TextView auto=button("Borrar notas descartadas al acertar: "+(cleanRelatedNotes?"Sí":"No"),false);
        add(page,auto,12);auto.setOnClickListener(v->{cleanRelatedNotes=!cleanRelatedNotes;prefs.edit().putBoolean("clean_related_notes",cleanRelatedNotes).apply();showOptions();});
        TextView candidates=button("Mostrar posibilidades en casilla: "+(showCandidates?"Sí":"No"),false);
        add(page,candidates,12);candidates.setOnClickListener(v->{showCandidates=!showCandidates;prefs.edit().putBoolean("show_candidates",showCandidates).apply();showOptions();});
        TextView digits=button("Números grandes en tablero: "+(largeNumbers?"Sí":"No"),false);
        add(page,digits,12);digits.setOnClickListener(v->{largeNumbers=!largeNumbers;prefs.edit().putBoolean("large_numbers",largeNumbers).apply();showOptions();});
        TextView timer=button("Mostrar cronómetro: "+(prefs.getBoolean("show_timer",true)?"Sí":"No"),false);
        add(page,timer,12);timer.setOnClickListener(v->{prefs.edit().putBoolean("show_timer",!prefs.getBoolean("show_timer",true)).apply();showOptions();});
        card("Modo de juego tranquilo","No existe límite de tiempo ni penalización. Puedes ocultar el reloj y seguir a tu ritmo.",null,false,null);
        card("Privacidad","Todos tus datos de partidas y aprendizaje se guardan en este dispositivo. No se solicitan cuentas ni permisos de Internet.",null,false,null);
    }
    private void pickTheme(Runnable after){
        String[] options=new String[ThemePalette.ALL.length];
        for(int i=0;i<options.length;i++)options[i]=ThemePalette.ALL[i].name;
        new AlertDialog.Builder(this).setTitle("Elegir tema de colores")
            .setSingleChoiceItems(options,prefs.getInt("color_theme",0),(dialog,index)->{
                prefs.edit().putInt("color_theme",index).apply();dialog.dismiss();after.run();
            }).setNegativeButton("Cancelar",null).show();
    }
    private static final int[][] FOUR={{1,2,3,4},{3,4,1,2},{2,1,4,3},{4,3,2,1}};
    private static final String[] LESSON_TITLES={"Conoce las reglas","La fila","La columna","Los bloques","Del 1 al 9","¡Primeros pasos superados!"};
    private static final String[] LESSON_TEXT={
        "Un Sudoku tradicional tiene 9 filas, 9 columnas y nueve bloques de 3×3. Debes colocar los números del 1 al 9 sin repetir ninguno en cada fila, columna o bloque. Empezaremos con un tablero reducido de 4×4 para practicar las mismas reglas con los números del 1 al 4.",
        "Una fila es una línea horizontal. Mira los números de esta fila y descubre cuál falta.",
        "Una columna es una línea vertical. Observa ahora la segunda columna: ¿qué número falta en la casilla señalada?",
        "Cada bloque de 2×2 de este tablero pequeño también debe tener los números del 1 al 4 sin repetir. ¿Qué cifra necesita el bloque superior derecho?",
        "Pasamos al tablero normal, con cifras del 1 al 9. Esta primera fila tiene ocho números. ¿Qué número falta?",
        "Ya conoces filas, columnas y bloques. Puedes empezar con Sudokus de nivel fácil y volver a la Escuela cuando quieras. Las siguientes técnicas se añadirán en próximas actualizaciones."
    };
    private static final int[] ANSWERS={0,2,2,1,9,0};
    private void showLessons(){
        initScreen(LESSONS);lessonTarget=null;topBar("Escuela de Sudoku",this::showHome);
        TextView progress=text("LECCIÓN "+(lessonStep+1)+" DE 6",11,true,colors.accent);add(page,progress,18);
        heading(null,LESSON_TITLES[lessonStep],LESSON_TEXT[lessonStep]);
        if(lessonStep<=4){
            int[][] grid;
            int targetRow,targetCol;
            if(lessonStep==4){
                grid=new int[9][9];
                String solved="123456789456789123789123456234567891567891234891234567345678912678912345912345678";
                for(int r=0;r<9;r++)for(int c=0;c<9;c++)grid[r][c]=solved.charAt(r*9+c)-'0';
                targetRow=0;targetCol=8;
            }else{
                grid=new int[4][4];for(int r=0;r<4;r++)System.arraycopy(FOUR[r],0,grid[r],0,4);
                targetRow=lessonStep==1?0:lessonStep==2?0:1;
                targetCol=lessonStep==1?1:lessonStep==2?1:2;
            }
            grid[targetRow][targetCol]=0;
            renderLessonGrid(grid,targetRow,targetCol);
            if(lessonStep>0){
                add(page,text("Elige el número que debe ir en la casilla marcada:",15,true,colors.ink),15);
                LinearLayout candidates=row();
                int max=lessonStep==4?9:4;
                for(int n=1;n<=max;n++){
                    int value=n;
                    TextView option=button(String.valueOf(n),false);option.setTextSize(max==9?18:20);
                    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1f);
                    p.setMargins(dp(2),0,dp(2),0);candidates.addView(option,p);
                    option.setOnClickListener(v->checkLessonAnswer(value));
                }
                add(page,candidates,10);
                lessonFeedback=text(lessonCorrect?"Correcto. ¡Has utilizado la lógica!":"Prueba una respuesta. Puedes equivocarte sin penalizaciones.",13,false,lessonCorrect?colors.accent:colors.muted);
                add(page,lessonFeedback,12);
            }
        }
        lessonNext=button(lessonStep==5?"Empezar una partida":lessonStep==0?"Ir al primer ejercicio":"Siguiente lección →",true);
        add(page,lessonNext,18);
        lessonNext.setEnabled(lessonStep==0||lessonStep==5||lessonCorrect);
        lessonNext.setAlpha(lessonNext.isEnabled()?1:.55f);
        lessonNext.setOnClickListener(v->{
            if(lessonStep==5){showHome();chooseNewGame();return;}
            if(lessonStep>0&&!lessonCorrect)return;
            lessonStep++;lessonCorrect=false;
            prefs.edit().putInt("lesson_progress",Math.max(prefs.getInt("lesson_progress",0),lessonStep)).apply();
            showLessons();
        });
        if(lessonStep>0){
            TextView reset=button("Repetir desde el principio",false);add(page,reset,12);
            reset.setOnClickListener(v->{lessonStep=0;lessonCorrect=false;showLessons();});
        }
    }
    private void renderLessonGrid(int[][] grid,int targetRow,int targetCol){
        int n=grid.length;
        LinearLayout outer=column();outer.setPadding(dp(3),dp(3),dp(3),dp(3));
        outer.setBackground(background(colors.surface,12,colors.border));
        for(int r=0;r<n;r++){
            LinearLayout line=row();
            for(int c=0;c<n;c++){
                boolean isTarget=r==targetRow&&c==targetCol;
                TextView cell=text(isTarget?"?":String.valueOf(grid[r][c]),n==4?25:17,true,isTarget?colors.accent:colors.given);
                cell.setGravity(Gravity.CENTER);
                if(isTarget)lessonTarget=cell;
                GradientDrawable bg=background(isTarget?colors.selection:colors.board,0,colors.grid);
                // Un borde más oscuro al terminar cada bloque hace visible la regla.
                cell.setBackground(bg);
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(n==4?63:38),1f);
                cp.setMargins(dp(1),dp(1),dp(1),dp(1));
                line.addView(cell,cp);
            }
            add(outer,line,0);
        }
        add(page,outer,19);
    }
    private void checkLessonAnswer(int value){
        if(lessonCorrect)return;
        if(value==ANSWERS[lessonStep]){
            lessonCorrect=true;
            lessonFeedback.setText("¡Correcto! Has encontrado el número usando la regla que acabamos de estudiar.");
            if(lessonTarget!=null){lessonTarget.setText(String.valueOf(value));lessonTarget.setTextColor(colors.entered);}
            lessonFeedback.setTextColor(colors.accent);
            lessonNext.setEnabled(true);lessonNext.setAlpha(1f);
        }else{
            lessonFeedback.setText("Ese número ya aparece en la fila, columna o bloque que estamos estudiando. Vuelve a observar.");
            lessonFeedback.setTextColor(colors.muted);
        }
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
    private void persistGame(){
        if(game==null)return;
        try{
            JSONObject json=new JSONObject();
            json.put("diff",game.difficulty);json.put("index",game.index);json.put("generated",game.generated);
            if(game.generated){json.put("seed",Long.toString(game.seed));json.put("puzzle",SudokuLogic.encode(game.original));}
            json.put("cells",SudokuLogic.encode(game.cells));
            JSONArray notes=new JSONArray();for(int value:game.notes)notes.put(value);
            json.put("notes",notes);json.put("seconds",game.seconds);json.put("mistakes",game.mistakes);json.put("hints",game.hints);
            prefs.edit().putString(SAVE_KEY,json.toString()).apply();
        }catch(Exception ignored){toast("No se ha podido guardar la partida");}
    }
    private void restoreGame(){
        String raw=prefs.getString(SAVE_KEY,null);
        if(raw==null)return;
        try{
            JSONObject json=new JSONObject(raw);
            int diff=json.getInt("diff"),index=json.getInt("index");
            boolean generated=json.optBoolean("generated",false);
            if(diff<0||diff>=3||(!generated&&(index<0||index>=12)))throw new IllegalArgumentException("Partida no válida");
            GameState saved;
            if(generated){
                long seed=Long.parseLong(json.getString("seed"));
                saved=GameState.generated(diff,seed);
                if(!SudokuLogic.encode(saved.original).equals(json.getString("puzzle")))throw new IllegalArgumentException("Semilla del tablero inconsistente");
            }else saved=new GameState(diff,index);
            int[] loaded=SudokuLogic.parse(json.getString("cells"));
            JSONArray notes=json.getJSONArray("notes");
            if(notes.length()!=81)throw new IllegalArgumentException("Notas incorrectas");
            for(int i=0;i<81;i++){
                if(loaded[i]<0||loaded[i]>9||(saved.locked(i)&&loaded[i]!=saved.original[i]))throw new IllegalArgumentException("Números o pistas fijas inválidas");
                saved.cells[i]=loaded[i];saved.notes[i]=notes.optInt(i,0)&0x3FE;
            }
            saved.seconds=Math.max(0,json.optInt("seconds",0));
            saved.mistakes=Math.max(0,json.optInt("mistakes",0));saved.hints=Math.max(0,json.optInt("hints",0));
            if(!saved.solved())game=saved;
        }catch(Exception ignored){prefs.edit().remove(SAVE_KEY).apply();game=null;}
    }
}
