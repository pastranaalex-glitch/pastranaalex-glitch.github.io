package es.bibliotecadeherramientas.sudokuvivo;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/** Tablero vectorial 9x9, dibujado a resolución nativa y adaptado a la pantalla. */
public final class SudokuBoardView extends View {
    public interface OnCellTap { void tapped(int cell); }
    private GameState game;
    private ThemePalette colors=ThemePalette.of(0);
    private final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
    private int selected=-1,hint=-1;
    private boolean revealErrors=true,largeNumbers=false;
    private OnCellTap listener;
    public SudokuBoardView(Context context){super(context);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);setContentDescription("Tablero de Sudoku de nueve filas y nueve columnas");}
    public void setGame(GameState g){game=g;invalidate();}
    public void setTheme(ThemePalette t){colors=t;invalidate();}
    public void setSelected(int position){selected=position;invalidate();}
    public int getSelected(){return selected;}
    public void setHint(int position){hint=position;invalidate();}
    public void setRevealErrors(boolean show){revealErrors=show;invalidate();}
    public void setLargeNumbers(boolean value){largeNumbers=value;invalidate();}
    public void setOnCellTap(OnCellTap callback){listener=callback;}
    @Override protected void onMeasure(int widthSpec,int heightSpec){
        int width=MeasureSpec.getSize(widthSpec);
        if(MeasureSpec.getMode(widthSpec)==MeasureSpec.UNSPECIFIED)width=340;
        int height=width;
        if(MeasureSpec.getMode(heightSpec)==MeasureSpec.AT_MOST)height=Math.min(height,MeasureSpec.getSize(heightSpec));
        setMeasuredDimension(width,height);
    }
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        if(game==null)return;
        float side=Math.min(getWidth(),getHeight()),cell=side/9f;
        fill(canvas,0,0,side,side,colors.board);
        int chosenNumber=selected>=0?game.cells[selected]:0;
        for(int pos=0;pos<81;pos++){
            int r=pos/9,c=pos%9;
            int fill=colors.board;
            if(selected>=0){
                int sr=selected/9,sc=selected%9;
                if(r==sr||c==sc||(r/3==sr/3&&c/3==sc/3))fill=colors.related;
                if(chosenNumber!=0&&game.cells[pos]==chosenNumber)fill=colors.same;
            }
            if(pos==hint)fill=colors.same;
            if(pos==selected)fill=colors.selection;
            if(fill!=colors.board)fill(canvas,c*cell,r*cell,(c+1)*cell,(r+1)*cell,fill);
        }
        for(int pos=0;pos<81;pos++){
            int r=pos/9,c=pos%9,n=game.cells[pos];
            if(n!=0){
                boolean isError=revealErrors&&!game.locked(pos)&&game.solution[pos]!=n;
                pen.setTypeface(Typeface.create("sans-serif-medium",game.locked(pos)?Typeface.BOLD:Typeface.NORMAL));
                pen.setColor(isError?colors.error:(game.locked(pos)?colors.given:colors.entered));
                pen.setTextSize(cell*(largeNumbers?.66f:.54f));
                pen.setTextAlign(Paint.Align.CENTER);
                Paint.FontMetrics fm=pen.getFontMetrics();
                canvas.drawText(String.valueOf(n),(c+.5f)*cell,(r+.5f)*cell-(fm.ascent+fm.descent)/2,pen);
            }else if(game.notes[pos]!=0){
                pen.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
                pen.setTextSize(cell*.215f);pen.setColor(colors.note);pen.setTextAlign(Paint.Align.CENTER);
                for(int k=1;k<=9;k++){
                    if((game.notes[pos]&(1<<k))==0)continue;
                    int i=k-1,rr=i/3,cc=i%3;
                    float bx=c*cell+(cc+.5f)*cell/3;
                    float by=r*cell+(rr+.68f)*cell/3;
                    canvas.drawText(String.valueOf(k),bx,by,pen);
                }
            }
        }
        for(int i=0;i<=9;i++){
            float p=i*cell;
            pen.setColor(i%3==0?colors.major:colors.grid);
            pen.setStrokeWidth(dp(i%3==0?2.1f:.75f));
            canvas.drawLine(0,p,side,p,pen);canvas.drawLine(p,0,p,side,pen);
        }
        if(hint>=0){
            pen.setColor(colors.accent);pen.setStrokeWidth(dp(2.2f));pen.setStyle(Paint.Style.STROKE);
            int r=hint/9,c=hint%9;canvas.drawRect(new RectF(c*cell+2,r*cell+2,(c+1)*cell-2,(r+1)*cell-2),pen);
            pen.setStyle(Paint.Style.FILL);
        }
    }
    private void fill(Canvas canvas,float l,float t,float r,float b,int color){pen.setColor(color);pen.setStyle(Paint.Style.FILL);canvas.drawRect(l,t,r,b,pen);}
    private float dp(float v){return getResources().getDisplayMetrics().density*v;}
    @Override public boolean onTouchEvent(MotionEvent event){
        if(event.getAction()==MotionEvent.ACTION_UP){
            int col=(int)(event.getX()*9/getWidth()),row=(int)(event.getY()*9/getHeight());
            if(col>=0&&col<9&&row>=0&&row<9&&listener!=null)listener.tapped(row*9+col);
            performClick();return true;
        }
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
