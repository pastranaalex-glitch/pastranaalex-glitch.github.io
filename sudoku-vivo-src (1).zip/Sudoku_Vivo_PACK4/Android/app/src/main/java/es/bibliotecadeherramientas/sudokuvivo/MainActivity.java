package es.bibliotecadeherramientas.sudokuvivo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;

/** Sudoku Vivo Pack 4: lógica, enseñanza y nueve niveles de aventura sin conexión. */
public final class MainActivity extends Activity {
    private static final String PREFS="sudoku_vivo_local_v1";
    private static final String SAVE_KEY="partida_guardada";
    private static final int HOME=0,GAME=1,LESSONS=2,ADVENTURE=3,OPTIONS=4,GALLERY=5;
    private SharedPreferences prefs;
    private ThemePalette colors;
    private GameState game;
    private int screen=HOME,selectedCell=-1,lessonStep=0,adventureLevel=-1;
    private boolean noteMode=false,showErrors=true,resumed=false,lessonCorrect=false;
    private ScrollView scroll;
    private LinearLayout page;
    private SudokuBoardView boardView;
    private TextView gameInfo,noteAction,lessonFeedback,lessonNext,lessonTarget,candidateInfo,adventureInfo;
    private AdventureRevealView adventureReveal;
    private boolean cleanRelatedNotes=true,showCandidates=true,largeNumbers=false;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable clock=new Runnable(){
        @Override public void run(){
            if(resumed){
                if(screen==GAME&&game!=null&&!game.solved()){
                    game.seconds++;
                    refreshGameInfo();
                    if(game.seconds%5==0)persistGame();
                }
                handler.postDelayed(this,1000);
            }
        }
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
        colors=ThemePalette.of(prefs.getInt("color_theme",0));
        showErrors=prefs.getBoolean("show_errors",true);
        cleanRelatedNotes=prefs.getBoolean("clean_related_notes",true);
        showCandidates=prefs.getBoolean("show_candidates",true);
        largeNumbers=prefs.getBoolean("large_numbers",false);
        restoreGame();
        showHome();
    }
    @Override protected void onResume(){super.onResume();resumed=true;handler.removeCallbacks(clock);handler.postDelayed(clock,1000);}
    @Override protected void onPause(){resumed=false;handler.removeCallbacks(clock);persistGame();super.onPause();}
    @Override public void onBackPressed(){
        if(screen==HOME){super.onBackPressed();return;}
        persistGame();
        if(screen==GALLERY){showAdventure();return;}
        if(screen==GAME&&adventureLevel>=0){showAdventure();return;}
        showHome();
    }

    private int dp(float x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
    private GradientDrawable background(int color,int radius,int stroke){
        GradientDrawable drawable=new GradientDrawable();
        drawable.setColor(color);drawable.setCornerRadius(dp(radius));
        if(stroke!=0)drawable.setStroke(dp(1),stroke);
        return drawable;
    }
    private TextView text(String content,int sp,boolean bold,int color){
        TextView view=new TextView(this);
        view.setText(content);view.setTextColor(color);view.setTextSize(TypedValue.COMPLEX_UNIT_SP,sp);
        view.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        view.setIncludeFontPadding(true);view.setLineSpacing(dp(2),1.06f);
        return view;
    }
    private TextView button(String label,boolean prominent){
        TextView button=text(label,15,true,prominent?colors.surface:colors.ink);
        button.setGravity(Gravity.CENTER);button.setPadding(dp(13),dp(12),dp(13),dp(12));
        button.setMinHeight(dp(49));
        button.setBackground(background(prominent?colors.accent:colors.button,13,prominent?0:colors.border));
        button.setClickable(true);button.setFocusable(true);
        return button;
    }
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void add(LinearLayout parent,View view,int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(view,p);
    }
    private void spaced(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void initScreen(int kind){
        screen=kind;boardView=null;gameInfo=null;noteAction=null;candidateInfo=null;adventureInfo=null;adventureReveal=null;
        colors=ThemePalette.of(prefs.getInt("color_theme",0));
        getWindow().setStatusBarColor(colors.bg);getWindow().setNavigationBarColor(colors.bg);
        boolean light=prefs.getInt("color_theme",0)!=1;
        int flags=getWindow().getDecorView().getSystemUiVisibility();
        if(light)flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        else flags&=~(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setSystemUiVisibility(flags);
        scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(colors.bg);
        scroll.setClipToPadding(false);
        int hor=dp(15),vertical=dp(13);
        scroll.setPadding(hor,vertical,hor,dp(22));
        scroll.setOnApplyWindowInsetsListener((v,insets)->{
            // Los teléfonos con interfaz borde a borde no deben tapar ningún control.
            int top=insets.getSystemWindowInsetTop(),bottom=insets.getSystemWindowInsetBottom();
            v.setPadding(hor,Math.max(vertical,top+dp(7)),hor,Math.max(dp(22),bottom+dp(7)));
            return insets;
        });
        page=column();page.setPadding(dp(2),dp(6),dp(2),dp(8));
        scroll.addView(page,new ScrollView.LayoutParams(-1,-2));
        setContentView(scroll);
    }
    private void heading(String eyebrow,String headline,String details){
        if(eyebrow!=null)add(page,text(eyebrow.toUpperCase(Locale.ROOT),11,true,colors.accent),4);
        if(headline!=null)add(page,text(headline,28,true,colors.ink),8);
        if(details!=null)add(page,text(details,14,false,colors.muted),7);
    }
    private void card(String title,String body,String action,boolean active,Runnable run){
        LinearLayout box=column();box.setPadding(dp(17),dp(15),dp(17),dp(15));
        box.setBackground(background(colors.surface,18,colors.border));
        add(box,text(title,19,true,colors.ink),0);
        add(box,text(body,14,false,colors.muted),8);
        if(action!=null){
            TextView link=button(action,active);
            link.setEnabled(active);link.setAlpha(active?1f:.5f);
            add(box,link,12);
            if(active&&run!=null)link.setOnClickListener(v->run.run());
        }
        add(page,box,13);
    }
    private void topBar(String title,Runnable back){
        LinearLayout bar=row();
        TextView go=button("‹",false);go.setTextSize(26);go.setMinWidth(dp(52));
        bar.addView(go,new LinearLayout.LayoutParams(dp(52),dp(49)));
        go.setContentDescription("Volver a inicio");go.setOnClickListener(v->back.run());
        TextView name=text(title,19,true,colors.ink);name.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1f);np.leftMargin=dp(13);
        bar.addView(name,np);add(page,bar,2);
    }
    private void showHome(){
        initScreen(HOME);
        heading("Biblioteca de herramientas","Sudoku Vivo","Aprende, resuelve y descubre. Un juego de lógica pensado para disfrutar a tu ritmo.");
        if(game!=null){
            card("Continuar partida",PuzzleBank.DIFFICULTIES[game.difficulty]+" · "+(game.generated?"Sudoku generado":"Colección · Tablero "+(game.index+1))+" · "+game.filled()+"/81 casillas completas","Seguir jugando",true,()->showGame());
        }
        card("Sudoku clásico sin límites","Nuevos sudokus con solución única en tres dificultades. Notas inteligentes, pistas razonadas y guardado automático.","Nuevo Sudoku",true,()->chooseNewGame(true));
        card("Colección inicial","Si lo prefieres, también puedes jugar los 36 tableros originales, conservados del primer pack.","Explorar colección",true,()->chooseNewGame(false));
        card("Escuela de Sudoku","Aprende las reglas desde cero. Diez lecciones progresivas con ejercicios razonados, sin cronómetro ni presión.","Empezar a aprender",true,()->{lessonStep=Math.min(prefs.getInt("lesson_progress",0),9);lessonCorrect=false;showLessons();});
        card("Aventura visual","Nueve niveles repartidos en tres mundos. Cada región del Sudoku descubre una parte de una imagen. Guarda tus logros en la galería.","Explorar aventura",true,this::showAdventure);
        TextView settings=button("Colores y preferencias",false);add(page,settings,13);settings.setOnClickListener(v->showOptions());
        TextView footer=text("Versión 0.4.0 · Pack 4 · Sin anuncios · Sin conexión necesaria",12,false,colors.muted);
        footer.setGravity(Gravity.CENTER);add(page,footer,20);
    }
    private void chooseNewGame(){chooseNewGame(true);}
    private void chooseNewGame(boolean generated){
        new AlertDialog.Builder(this).setTitle(generated?"Elegir dificultad · Sudoku nuevo":"Elegir dificultad · Colección")
          .setItems(new String[]{"Fácil · para empezar","Media · un poco más de lógica","Difícil · mayor desafío"},(dialog,which)->{
            Runnable start=()->{
                int index=prefs.getInt("completed_"+which,0)%PuzzleBank.PER_DIFFICULTY;
                if(generated){
                    // Evita repetir la semilla si se crean partidas con pocos milisegundos de diferencia.
                    long sequence=prefs.getLong("generated_sequence",0L)+1L;
                    prefs.edit().putLong("generated_sequence",sequence).apply();
                    long seed=System.nanoTime()^(sequence*0x9E3779B97F4A7C15L);
                    game=GameState.generated(which,seed);
                }else game=new GameState(which,index);
                adventureLevel=-1;selectedCell=firstBlank();noteMode=false;persistGame();showGame();
            };
            if(game!=null&&!game.solved())new AlertDialog.Builder(this).setTitle("¿Empezar otra partida?").setMessage("Se reemplazará la partida que tienes a medias. Si prefieres, vuelve y pulsa «Continuar partida».").setNegativeButton("Cancelar",null).setPositiveButton("Nueva partida",(d,w)->start.run()).show();
            else start.run();
        }).show();
    }
    private int firstBlank(){if(game==null)return -1;for(int i=0;i<81;i++)if(!game.locked(i))return i;return -1;}
    private void showGame(){
        if(game==null){showHome();return;}
        initScreen(GAME);
        topBar(adventureLevel>=0?"Aventura · Nivel "+(adventureLevel+1):"Sudoku Vivo",()->{persistGame();if(adventureLevel>=0)showAdventure();else showHome();});
        LinearLayout header=row();
        String mode=adventureLevel>=0?AdventureProgress.LEVEL_TITLES[adventureLevel]:(game.generated?"Sudoku nuevo":"Colección "+(game.index+1)+"/12");
        TextView meta=text(PuzzleBank.DIFFICULTIES[game.difficulty]+" · "+mode,15,true,colors.ink);
        header.addView(meta,new LinearLayout.LayoutParams(0,-2,1f));
        TextView palette=button("◐ Tema",false);palette.setTextSize(13);
        header.addView(palette,new LinearLayout.LayoutParams(-2,dp(43)));
        palette.setOnClickListener(v->pickTheme(()->showGame()));
        add(page,header,14);
        gameInfo=text("",12,false,colors.muted);add(page,gameInfo,8);
        boardView=new SudokuBoardView(this);
        boardView.setGame(game);boardView.setTheme(colors);boardView.setRevealErrors(showErrors);
        boardView.setLargeNumbers(largeNumbers);
        if(selectedCell<0||selectedCell>80)selectedCell=firstBlank();
        boardView.setSelected(selectedCell);
        boardView.setOnCellTap(pos->{selectedCell=pos;boardView.setSelected(pos);boardView.setHint(-1);refreshCandidateInfo();});
        LinearLayout boardWrap=column();boardWrap.setBackground(background(colors.surface,12,colors.border));
        boardWrap.setPadding(dp(3),dp(3),dp(3),dp(3));
        boardWrap.addView(boardView,new LinearLayout.LayoutParams(-1,-2));
        add(page,boardWrap,12);
        candidateInfo=text("",12,false,colors.muted);add(page,candidateInfo,8);
        LinearLayout numbers=row();numbers.setGravity(Gravity.CENTER);
        for(int number=1;number<=9;number++){
            final int n=number;
            TextView key=button(String.valueOf(n),false);key.setTextSize(20);key.setMinHeight(dp(48));key.setPadding(0,0,0,0);
            LinearLayout.LayoutParams kp=new LinearLayout.LayoutParams(0,dp(49),1f);
            kp.setMargins(dp(1),0,dp(1),0);
            numbers.addView(key,kp);key.setOnClickListener(v->putNumber(n));
        }
        add(page,numbers,14);
        LinearLayout actions=row();
        String[] labels={"↶\nDeshacer","✎\nNotas","⌫\nBorrar","?\nPista"};
        for(int i=0;i<labels.length;i++){
            final int action=i;
            TextView item=button(labels[i],false);
            item.setTextSize(12);item.setPadding(dp(3),dp(7),dp(3),dp(7));
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(54),1f);
            ap.setMargins(dp(3),0,dp(3),0);
            actions.addView(item,ap);
            if(i==1)noteAction=item;
            item.setOnClickListener(v->{
                switch(action){
                    case 0: if(game.undo()){gameChanged();}else toast("No hay cambios para deshacer");break;
                    case 1: noteMode=!noteMode;styleNoteButton();break;
                    case 2: putNumber(0);break;
                    case 3: requestHint();break;
                    default:break;
                }
            });
        }
        add(page,actions,12);
        LinearLayout noteTools=row();
        TextView automatic=button("✎  Notas posibles",false);
        TextView clear=button("Limpiar notas",false);
        TextView redo=button("↷  Rehacer",false);
        for(TextView tool:new TextView[]{automatic,clear,redo}){
            tool.setTextSize(12);tool.setPadding(dp(4),dp(9),dp(4),dp(9));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1f);p.setMargins(dp(2),0,dp(2),0);
            noteTools.addView(tool,p);
        }
        automatic.setOnClickListener(v->{
            int changed=game.fillAutomaticNotes(false);if(changed>0){gameChanged();toast("Notas calculadas en "+changed+" casillas");}
            else toast("Las notas ya están actualizadas");
        });
        clear.setOnClickListener(v->{int count=game.clearNotes();if(count>0){gameChanged();toast("Notas borradas");}else toast("No hay notas que borrar");});
        redo.setOnClickListener(v->{if(game.redo())gameChanged();else toast("No hay cambios para rehacer");});
        add(page,noteTools,8);
        TextView tip=text("Toca una casilla y elige un número. Las notas posibles se calculan a partir de las reglas, sin mostrarte la solución. Puedes continuar tu partida en cualquier momento.",12,false,colors.muted);
        add(page,tip,13);
        if(adventureLevel>=0){
            TextView caption=text("IMAGEN EN DESCUBRIMIENTO",11,true,colors.accent);
            add(page,caption,18);
            adventureInfo=text("",14,true,colors.ink);add(page,adventureInfo,7);
            adventureReveal=new AdventureRevealView(this,adventureImage(adventureLevel),AdventureProgress.revealedMask(game),0xE21B2939);
            add(page,adventureReveal,9);
            add(page,text("Completa correctamente un bloque de 3×3 para revelar una parte del paisaje. Las notas y los números incorrectos no cuentan.",12,false,colors.muted),10);
            refreshAdventureInfo();
        }
        styleNoteButton();refreshGameInfo();refreshCandidateInfo();
    }
    private void styleNoteButton(){
        if(noteAction==null)return;
        noteAction.setBackground(background(noteMode?colors.accent:colors.button,13,noteMode?0:colors.border));
        noteAction.setTextColor(noteMode?colors.surface:colors.ink);
        noteAction.setContentDescription(noteMode?"Modo notas activado":"Modo notas desactivado");
    }
    private void refreshGameInfo(){
        if(gameInfo==null||game==null)return;
        int secs=game.seconds;
        String time=prefs.getBoolean("show_timer",true)?String.format(Locale.getDefault(),"%02d:%02d  ·  ",secs/60,secs%60):"";
        gameInfo.setText(time+game.filled()+" de 81 casillas  ·  "+game.hints+" pistas  ·  "+game.mistakes+" intentos erróneos");
    }
    private void gameChanged(){
        if(boardView!=null){boardView.setHint(-1);boardView.invalidate();}
        persistGame();refreshGameInfo();refreshCandidateInfo();refreshAdventureInfo();
    }
    private void refreshCandidateInfo(){
        if(candidateInfo==null||game==null)return;
        if(selectedCell<0||selectedCell>=81){candidateInfo.setText("Selecciona una casilla del tablero.");return;}
        String pos="Fila "+(selectedCell/9+1)+", columna "+(selectedCell%9+1);
        if(game.locked(selectedCell)) {candidateInfo.setText(pos+" · Número fijo");return;}
        if(game.cells[selectedCell]!=0) {candidateInfo.setText(pos+" · Valor introducido: "+game.cells[selectedCell]);return;}
        if(!showCandidates){candidateInfo.setText(pos+" · Casilla vacía");return;}
        int mask=SudokuLogic.candidateMask(game.cells,selectedCell);
        StringBuilder opts=new StringBuilder();
        for(int n=1;n<=9;n++)if((mask&(1<<n))!=0){if(opts.length()>0)opts.append(", ");opts.append(n);}
        candidateInfo.setText(pos+" · Posibles: "+(opts.length()==0?"ninguno (revisa tus números)":opts.toString()));
    }
    private void putNumber(int n){
        if(game==null||boardView==null)return;
        if(selectedCell<0){toast("Selecciona una casilla");return;}
        if(game.locked(selectedCell)){toast("Este número es una pista fija del tablero");return;}
        if(game.change(selectedCell,n,noteMode,cleanRelatedNotes)){
            if(!noteMode&&n>0&&game.cells[selectedCell]!=game.solution[selectedCell])game.mistakes++;
            gameChanged();
            if(game.solved())finishGame();
        }
    }
    private void requestHint(){
        if(game==null)return;
        for(int i=0;i<81;i++) {
            if(game.cells[i]!=0&&game.cells[i]!=game.solution[i]){
                new AlertDialog.Builder(this).setTitle("Revisa el tablero").setMessage("Hay un número que todavía no encaja en la solución. Corrígelo antes de solicitar una pista lógica.").setPositiveButton("Entendido",null).show();
                return;
            }
        }
        SudokuLogic.Hint hint=SudokuLogic.findHint(game.cells,game.solution);
        if(hint==null){toast("¡Tablero completado!");return;}
        selectedCell=hint.position;boardView.setSelected(hint.position);boardView.setHint(hint.position);
        int row=hint.position/9+1,col=hint.position%9+1;
        String where="Fila "+row+", columna "+col+".\n\n"+hint.explanation;
        new AlertDialog.Builder(this).setTitle(hint.isDirect?"Ayuda avanzada":"Pista de lógica")
            .setMessage(where+"\n\nLa casilla ya está señalada. Puedes cerrar esta ayuda e intentar deducir el número por ti mismo.")
            .setNegativeButton("Intentarlo yo",null)
            .setPositiveButton("Colocar "+hint.number,(dialog,which)->{
                if(game==null)return;
                if(game.change(hint.position,hint.number,false)){
                    game.hints++;gameChanged();
                    if(game.solved())finishGame();
                }
            }).show();
    }
    private void finishGame(){
        if(game==null)return;
        final int diff=game.difficulty,index=game.index,seconds=game.seconds,hints=game.hints;
        final boolean generated=game.generated;
        final int level=adventureLevel;
        String counter=generated?"completed_generated_"+diff:"completed_"+diff;
        SharedPreferences.Editor editor=prefs.edit().putInt(counter,prefs.getInt(counter,0)+1).remove(SAVE_KEY);
        if(level>=0){
            int mask=AdventureProgress.sanitizedMask(prefs.getInt("adventure_completed_mask",0));
            editor.putInt("adventure_completed_mask",AdventureProgress.complete(mask,level));
        }
        editor.apply();
        game=null;adventureLevel=-1; // Ninguna partida terminada queda pendiente.
        if(level>=0){
            new AlertDialog.Builder(this).setTitle("Paisaje descubierto")
                .setMessage("Has completado «"+AdventureProgress.LEVEL_TITLES[level]+"» en "+String.format(Locale.getDefault(),"%02d:%02d",seconds/60,seconds%60)+".\nPistas utilizadas: "+hints+".\n\nLa imagen se ha guardado en tu colección.")
                .setCancelable(false).setNegativeButton("Ver colección",(d,w)->showGallery())
                .setPositiveButton("Seguir aventura",(d,w)->showAdventure()).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("¡Sudoku completado!")
            .setMessage("Has completado "+(generated?"un Sudoku nuevo":"el tablero "+(index+1))+" en "+String.format(Locale.getDefault(),"%02d:%02d",seconds/60,seconds%60)+".\nPistas aplicadas: "+hints+".\n\nPuedes seguir practicando a tu ritmo.")
            .setCancelable(false)
            .setNegativeButton("Volver al inicio",(d,w)->showHome())
            .setPositiveButton("Siguiente tablero",(d,w)->{
                if(generated){
                    long sequence=prefs.getLong("generated_sequence",0L)+1L;
                    prefs.edit().putLong("generated_sequence",sequence).apply();
                    game=GameState.generated(diff,System.nanoTime()^(sequence*0x9E3779B97F4A7C15L));
                }else game=new GameState(diff,(index+1)%PuzzleBank.PER_DIFFICULTY);
                adventureLevel=-1;selectedCell=firstBlank();noteMode=false;persistGame();showGame();
            }).show();
    }
    private static int adventureImage(int level){
        switch(level){
            case 0:return R.drawable.aventura_01;
            case 1:return R.drawable.aventura_02;
            case 2:return R.drawable.aventura_03;
            case 3:return R.drawable.aventura_04;
            case 4:return R.drawable.aventura_05;
            case 5:return R.drawable.aventura_06;
            case 6:return R.drawable.aventura_07;
            case 7:return R.drawable.aventura_08;
            case 8:return R.drawable.aventura_09;
            default:throw new IllegalArgumentException("Imagen no disponible");
        }
    }
    private void refreshAdventureInfo(){
        if(adventureInfo==null||adventureLevel<0||game==null)return;
        int revealed=AdventureProgress.revealedMask(game);
        adventureInfo.setText(Integer.bitCount(revealed)+" de 9 partes descubiertas");
        if(adventureReveal!=null)adventureReveal.setMask(revealed);
    }
    private void startAdventureLevel(int level){
        int completed=AdventureProgress.sanitizedMask(prefs.getInt("adventure_completed_mask",0));
        if(!AdventureProgress.unlocked(completed,level)){toast("Completa primero los niveles anteriores");return;}
        if(game!=null&&!game.solved()&&adventureLevel==level){selectedCell=firstBlank();showGame();return;}
        Runnable begin=()->{
            game=GameState.generated(AdventureProgress.difficulty(level),AdventureProgress.seed(level));
            adventureLevel=level;selectedCell=firstBlank();noteMode=false;persistGame();showGame();
        };
        if(game!=null&&!game.solved()){
            new AlertDialog.Builder(this).setTitle("¿Empezar otra partida?")
                .setMessage("Se sustituirá la partida que tienes a medias. Puedes cancelarlo y continuarla desde Inicio.")
                .setNegativeButton("Cancelar",null).setPositiveButton("Empezar nivel",(d,w)->begin.run()).show();
        }else begin.run();
    }
    private void showAdventure(){
        initScreen(ADVENTURE);topBar("Aventura visual",this::showHome);
        int mask=AdventureProgress.sanitizedMask(prefs.getInt("adventure_completed_mask",0));
        heading("Tres mundos · Nueve paisajes","Viaje por la lógica","Resuelve sudokus para revelar nueve imágenes originales. Cada bloque de 3×3 correcto descubre una novena parte del paisaje.");
        add(page,text(AdventureProgress.count(mask)+" de "+AdventureProgress.LEVEL_COUNT+" paisajes descubiertos",15,true,colors.accent),16);
        TextView gallery=button("Abrir mi colección de imágenes",false);
        add(page,gallery,12);gallery.setOnClickListener(v->showGallery());
        if(game!=null&&adventureLevel>=0){
            int current=adventureLevel;
            card("Aventura en curso",AdventureProgress.LEVEL_TITLES[current]+" · "+Integer.bitCount(AdventureProgress.revealedMask(game))+" partes descubiertas","Continuar nivel",true,()->{selectedCell=firstBlank();showGame();});
        }
        for(int world=0;world<3;world++){
            final int w=world;
            LinearLayout section=column();section.setPadding(dp(16),dp(15),dp(16),dp(16));
            section.setBackground(background(colors.surface,17,colors.border));
            add(section,text(String.format(Locale.ROOT,"MUNDO %d · %s",world+1,AdventureProgress.WORLD_NAMES[world]),18,true,colors.ink),0);
            add(section,text(AdventureProgress.WORLD_DETAILS[world],13,false,colors.muted),5);
            for(int k=0;k<3;k++){
                final int level=w*3+k;
                boolean done=AdventureProgress.completed(mask,level),unlocked=AdventureProgress.unlocked(mask,level);
                LinearLayout item=row();
                TextView title=text((level+1)+". "+AdventureProgress.LEVEL_TITLES[level],14,true,unlocked?colors.ink:colors.muted);
                item.addView(title,new LinearLayout.LayoutParams(0,-2,1f));
                TextView go=button(done?"Ver":unlocked?"Jugar":"Cerrado",false);go.setTextSize(12);
                go.setMinWidth(dp(79));go.setEnabled(unlocked);go.setAlpha(unlocked?1f:0.5f);
                LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(dp(92),dp(44));gp.leftMargin=dp(7);item.addView(go,gp);
                if(done)go.setOnClickListener(v->showCompletedImage(level));
                else if(unlocked)go.setOnClickListener(v->startAdventureLevel(level));
                add(section,item,11);
            }
            add(page,section,13);
        }
        add(page,text("Los niveles se desbloquean por orden. Puedes volver a jugar los que ya has superado. Las imágenes se guardan únicamente en este dispositivo.",12,false,colors.muted),15);
    }
    private void showCompletedImage(int level){
        if(!AdventureProgress.completed(prefs.getInt("adventure_completed_mask",0),level)){toast("Imagen aún no desbloqueada");return;}
        LinearLayout content=column();content.setPadding(dp(8),dp(8),dp(8),dp(6));
        ImageView image=new ImageView(this);image.setImageResource(adventureImage(level));image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        content.addView(image,new LinearLayout.LayoutParams(-1,dp(244)));
        add(content,text(AdventureProgress.LEVEL_TITLES[level]+" · Mundo "+AdventureProgress.WORLD_NAMES[AdventureProgress.world(level)],13,false,colors.muted),10);
        new AlertDialog.Builder(this).setTitle("Imagen descubierta")
            .setView(content).setNegativeButton("Cerrar",null)
            .setPositiveButton("Volver a jugar",(d,w)->startAdventureLevel(level)).show();
    }
    private void showGallery(){
        initScreen(GALLERY);topBar("Mi colección",this::showAdventure);
        int mask=AdventureProgress.sanitizedMask(prefs.getInt("adventure_completed_mask",0));
        heading("Archivo personal","Paisajes descubiertos",AdventureProgress.count(mask)+" de 9 imágenes guardadas. Completa nuevos sudokus en Aventura para ampliar esta colección.");
        for(int level=0;level<AdventureProgress.LEVEL_COUNT;level++){
            boolean done=AdventureProgress.completed(mask,level);
            LinearLayout panel=column();panel.setBackground(background(colors.surface,16,colors.border));panel.setPadding(dp(13),dp(13),dp(13),dp(13));
            add(panel,text((level+1)+". "+AdventureProgress.LEVEL_TITLES[level],17,true,colors.ink),0);
            if(done){
                ImageView image=new ImageView(this);image.setImageResource(adventureImage(level));
                image.setAdjustViewBounds(true);image.setScaleType(ImageView.ScaleType.CENTER_CROP);
                LinearLayout.LayoutParams imageParams=new LinearLayout.LayoutParams(-1,dp(182));imageParams.topMargin=dp(10);
                panel.addView(image,imageParams);
                final int index=level;
                TextView see=button("Ampliar imagen",false);add(panel,see,10);see.setOnClickListener(v->showCompletedImage(index));
            }else add(panel,text("Imagen bloqueada · Resuelve el nivel para descubrirla.",13,false,colors.muted),9);
            add(page,panel,12);
        }
        add(page,text("Ilustraciones originales integradas en la aplicación. No necesitan conexión ni descargan contenido externo.",12,false,colors.muted),15);
    }
    private void showOptions(){
        initScreen(OPTIONS);topBar("Personalización",this::showHome);
        heading(null,"A tu gusto","Elige los colores que prefieras. Siempre mantendremos un tablero claro y fácil de leer.");
        TextView theme=button("Tema actual: "+colors.name+"  ›",false);
        add(page,theme,18);theme.setOnClickListener(v->pickTheme(this::showOptions));
        TextView errors=button("Marcar números incorrectos: "+(showErrors?"Sí":"No"),false);
        add(page,errors,13);
        errors.setOnClickListener(v->{showErrors=!showErrors;prefs.edit().putBoolean("show_errors",showErrors).apply();showOptions();});
        TextView auto=button("Borrar notas descartadas al acertar: "+(cleanRelatedNotes?"Sí":"No"),false);
        add(page,auto,12);auto.setOnClickListener(v->{cleanRelatedNotes=!cleanRelatedNotes;prefs.edit().putBoolean("clean_related_notes",cleanRelatedNotes).apply();showOptions();});
        TextView candidates=button("Mostrar posibilidades en casilla: "+(showCandidates?"Sí":"No"),false);
        add(page,candidates,12);candidates.setOnClickListener(v->{showCandidates=!showCandidates;prefs.edit().putBoolean("show_candidates",showCandidates).apply();showOptions();});
        TextView digits=button("Números grandes en tablero: "+(largeNumbers?"Sí":"No"),false);
        add(page,digits,12);digits.setOnClickListener(v->{largeNumbers=!largeNumbers;prefs.edit().putBoolean("large_numbers",largeNumbers).apply();showOptions();});
        TextView timer=button("Mostrar cronómetro: "+(prefs.getBoolean("show_timer",true)?"Sí":"No"),false);
        add(page,timer,12);timer.setOnClickListener(v->{prefs.edit().putBoolean("show_timer",!prefs.getBoolean("show_timer",true)).apply();showOptions();});
        card("Modo de juego tranquilo","No existe límite de tiempo ni penalización. Puedes ocultar el reloj y seguir a tu ritmo.",null,false,null);
        card("Privacidad","Todos tus datos de partidas y aprendizaje se guardan en este dispositivo. No se solicitan cuentas ni permisos de Internet.",null,false,null);
    }
    private void pickTheme(Runnable after){
        String[] options=new String[ThemePalette.ALL.length];
        for(int i=0;i<options.length;i++)options[i]=ThemePalette.ALL[i].name;
        new AlertDialog.Builder(this).setTitle("Elegir tema de colores")
            .setSingleChoiceItems(options,prefs.getInt("color_theme",0),(dialog,index)->{
                prefs.edit().putInt("color_theme",index).apply();dialog.dismiss();after.run();
            }).setNegativeButton("Cancelar",null).show();
    }
    private static final int[][] FOUR={{1,2,3,4},{3,4,1,2},{2,1,4,3},{4,3,2,1}};
    private static final String[] LESSON_TITLES={"Conoce las reglas","La fila","La columna","Los bloques","Del 1 al 9","Casilla única","Candidatos posibles","Descartar por columna","Repaso de lógica","¡Escuela inicial completada!"};
    private static final String[] LESSON_TEXT={
        "Un Sudoku tradicional tiene 9 filas, 9 columnas y nueve bloques de 3×3. Debes colocar los números del 1 al 9 sin repetir ninguno en cada fila, columna o bloque. Empezaremos con un tablero reducido de 4×4 para practicar las mismas reglas con los números del 1 al 4.",
        "Una fila es una línea horizontal. Mira los números de esta fila y descubre cuál falta.",
        "Una columna es una línea vertical. Observa ahora la segunda columna: ¿qué número falta en la casilla señalada?",
        "Cada bloque de 2×2 de este tablero pequeño también debe tener los números del 1 al 4 sin repetir. ¿Qué cifra necesita el bloque superior derecho?",
        "Pasamos al tablero normal, con cifras del 1 al 9. Esta primera fila tiene ocho números. ¿Qué número falta?",
        "A veces todos los números menos uno quedan descartados por la fila, columna y bloque. Resuelve esta casilla con una sola posibilidad.",
        "Las notas o candidatos son números que aún podrían ocupar una casilla. Primero descartamos los presentes en su fila, columna y bloque; elige la única posibilidad de la casilla señalada.",
        "Las columnas nos ayudan a descartar opciones. Observa la columna de la casilla marcada y comprueba qué cifra encaja también con su fila y bloque.",
        "Has aprendido a mirar varias reglas a la vez. Practica encontrando la cifra que falta y después aplica esta técnica en una partida real.",
        "¡Enhorabuena! Has terminado diez lecciones iniciales. Sigue practicando con Sudokus de nivel fácil. La ayuda del juego te señalará deducciones lógicas sin obligarte a revelar la respuesta."
    };
    private static final int[] ANSWERS={0,2,2,1,9,7,3,5,8,0};
    private void showLessons(){
        initScreen(LESSONS);lessonTarget=null;topBar("Escuela de Sudoku",this::showHome);
        TextView progress=text("LECCIÓN "+(lessonStep+1)+" DE 10",11,true,colors.accent);add(page,progress,18);
        heading(null,LESSON_TITLES[lessonStep],LESSON_TEXT[lessonStep]);
        if(lessonStep<=8){
            int[][] grid;
            int targetRow,targetCol;
            if(lessonStep>=4){
                grid=new int[9][9];
                String solved="123456789456789123789123456234567891567891234891234567345678912678912345912345678";
                for(int r=0;r<9;r++)for(int c=0;c<9;c++)grid[r][c]=solved.charAt(r*9+c)-'0';
                int[] indexes={8,6,2,4,7};
                targetRow=0;targetCol=indexes[lessonStep-4];
            }else{
                grid=new int[4][4];for(int r=0;r<4;r++)System.arraycopy(FOUR[r],0,grid[r],0,4);
                targetRow=lessonStep==1?0:lessonStep==2?0:1;
                targetCol=lessonStep==1?1:lessonStep==2?1:2;
            }
            grid[targetRow][targetCol]=0;
            renderLessonGrid(grid,targetRow,targetCol);
            if(lessonStep>0){
                add(page,text("Elige el número que debe ir en la casilla marcada:",15,true,colors.ink),15);
                LinearLayout candidates=row();
                int max=lessonStep>=4?9:4;
                for(int n=1;n<=max;n++){
                    int value=n;
                    TextView option=button(String.valueOf(n),false);option.setTextSize(max==9?18:20);
                    LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(48),1f);
                    p.setMargins(dp(2),0,dp(2),0);candidates.addView(option,p);
                    option.setOnClickListener(v->checkLessonAnswer(value));
                }
                add(page,candidates,10);
                lessonFeedback=text(lessonCorrect?"Correcto. ¡Has utilizado la lógica!":"Prueba una respuesta. Puedes equivocarte sin penalizaciones.",13,false,lessonCorrect?colors.accent:colors.muted);
                add(page,lessonFeedback,12);
            }
        }
        lessonNext=button(lessonStep==9?"Empezar una partida":lessonStep==0?"Ir al primer ejercicio":"Siguiente lección →",true);
        add(page,lessonNext,18);
        lessonNext.setEnabled(lessonStep==0||lessonStep==9||lessonCorrect);
        lessonNext.setAlpha(lessonNext.isEnabled()?1:.55f);
        lessonNext.setOnClickListener(v->{
            if(lessonStep==9){showHome();chooseNewGame();return;}
            if(lessonStep>0&&!lessonCorrect)return;
            lessonStep++;lessonCorrect=false;
            prefs.edit().putInt("lesson_progress",Math.max(prefs.getInt("lesson_progress",0),lessonStep)).apply();
            showLessons();
        });
        if(lessonStep>0){
            TextView reset=button("Repetir desde el principio",false);add(page,reset,12);
            reset.setOnClickListener(v->{lessonStep=0;lessonCorrect=false;showLessons();});
        }
    }
    private void renderLessonGrid(int[][] grid,int targetRow,int targetCol){
        int n=grid.length;
        LinearLayout outer=column();outer.setPadding(dp(3),dp(3),dp(3),dp(3));
        outer.setBackground(background(colors.surface,12,colors.border));
        for(int r=0;r<n;r++){
            LinearLayout line=row();
            for(int c=0;c<n;c++){
                boolean isTarget=r==targetRow&&c==targetCol;
                TextView cell=text(isTarget?"?":String.valueOf(grid[r][c]),n==4?25:17,true,isTarget?colors.accent:colors.given);
                cell.setGravity(Gravity.CENTER);
                if(isTarget)lessonTarget=cell;
                GradientDrawable bg=background(isTarget?colors.selection:colors.board,0,colors.grid);
                // Un borde más oscuro al terminar cada bloque hace visible la regla.
                cell.setBackground(bg);
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(n==4?63:38),1f);
                cp.setMargins(dp(1),dp(1),dp(1),dp(1));
                line.addView(cell,cp);
            }
            add(outer,line,0);
        }
        add(page,outer,19);
    }
    private void checkLessonAnswer(int value){
        if(lessonCorrect)return;
        if(value==ANSWERS[lessonStep]){
            lessonCorrect=true;
            lessonFeedback.setText("¡Correcto! Has encontrado el número usando la regla que acabamos de estudiar.");
            if(lessonTarget!=null){lessonTarget.setText(String.valueOf(value));lessonTarget.setTextColor(colors.entered);}
            lessonFeedback.setTextColor(colors.accent);
            lessonNext.setEnabled(true);lessonNext.setAlpha(1f);
        }else{
            lessonFeedback.setText("Ese número ya aparece en la fila, columna o bloque que estamos estudiando. Vuelve a observar.");
            lessonFeedback.setTextColor(colors.muted);
        }
    }
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_SHORT).show();}
    private void persistGame(){
        if(game==null)return;
        try{
            JSONObject json=new JSONObject();
            json.put("diff",game.difficulty);json.put("index",game.index);json.put("generated",game.generated);
            json.put("adventure_level",adventureLevel);
            if(game.generated){json.put("seed",Long.toString(game.seed));json.put("puzzle",SudokuLogic.encode(game.original));}
            json.put("cells",SudokuLogic.encode(game.cells));
            JSONArray notes=new JSONArray();for(int value:game.notes)notes.put(value);
            json.put("notes",notes);json.put("seconds",game.seconds);json.put("mistakes",game.mistakes);json.put("hints",game.hints);
            prefs.edit().putString(SAVE_KEY,json.toString()).apply();
        }catch(Exception ignored){toast("No se ha podido guardar la partida");}
    }
    private void restoreGame(){
        String raw=prefs.getString(SAVE_KEY,null);
        if(raw==null)return;
        try{
            JSONObject json=new JSONObject(raw);
            int diff=json.getInt("diff"),index=json.getInt("index");
            boolean generated=json.optBoolean("generated",false);
            if(diff<0||diff>=3||(!generated&&(index<0||index>=12)))throw new IllegalArgumentException("Partida no válida");
            GameState saved;
            if(generated){
                long seed=Long.parseLong(json.getString("seed"));
                saved=GameState.generated(diff,seed);
                if(!SudokuLogic.encode(saved.original).equals(json.getString("puzzle")))throw new IllegalArgumentException("Semilla del tablero inconsistente");
            }else saved=new GameState(diff,index);
            int[] loaded=SudokuLogic.parse(json.getString("cells"));
            JSONArray notes=json.getJSONArray("notes");
            if(notes.length()!=81)throw new IllegalArgumentException("Notas incorrectas");
            for(int i=0;i<81;i++){
                if(loaded[i]<0||loaded[i]>9||(saved.locked(i)&&loaded[i]!=saved.original[i]))throw new IllegalArgumentException("Números o pistas fijas inválidas");
                saved.cells[i]=loaded[i];saved.notes[i]=notes.optInt(i,0)&0x3FE;
            }
            saved.seconds=Math.max(0,json.optInt("seconds",0));
            saved.mistakes=Math.max(0,json.optInt("mistakes",0));saved.hints=Math.max(0,json.optInt("hints",0));
            if(!saved.solved()){
                game=saved;
                int storedLevel=json.optInt("adventure_level",-1);
                if(AdventureProgress.validLevel(storedLevel)
                    && saved.generated
                    && saved.seed==AdventureProgress.seed(storedLevel)
                    && saved.difficulty==AdventureProgress.difficulty(storedLevel)){
                    adventureLevel=storedLevel;
                }else adventureLevel=-1;
            }
        }catch(Exception ignored){prefs.edit().remove(SAVE_KEY).apply();game=null;adventureLevel=-1;}
    }
}
