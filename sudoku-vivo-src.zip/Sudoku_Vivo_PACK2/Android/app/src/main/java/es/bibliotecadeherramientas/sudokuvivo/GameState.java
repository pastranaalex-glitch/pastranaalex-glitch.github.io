package es.bibliotecadeherramientas.sudokuvivo;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/** Estado de partida y acciones reversibles, compatibles con los tableros del Pack 1. */
public final class GameState {
    public final int difficulty,index;
    public final long seed;
    public final boolean generated;
    public final int[] original,solution,cells,notes;
    public int seconds=0,mistakes=0,hints=0;
    private final Deque<Move> undoHistory=new ArrayDeque<>();
    private final Deque<Move> redoHistory=new ArrayDeque<>();
    private static final int MAX_UNDO=120;
    private static final class Move {
        final int[] oldCells,oldNotes,newCells,newNotes;
        Move(int[] oc,int[] on,int[] nc,int[] nn){oldCells=oc;oldNotes=on;newCells=nc;newNotes=nn;}
    }
    public GameState(int difficulty,int index) {this(difficulty,index,0L,false);}
    public static GameState generated(int difficulty,long seed){return new GameState(difficulty,-1,seed,true);}
    private GameState(int difficulty,int index,long seed,boolean generated) {
        this.difficulty=Math.max(0,Math.min(2,difficulty));
        this.index=generated?-1:Math.floorMod(index,PuzzleBank.PER_DIFFICULTY);
        this.seed=seed;this.generated=generated;
        original=generated?PuzzleGenerator.create(this.difficulty,seed):SudokuLogic.parse(PuzzleBank.get(this.difficulty,this.index));
        solution=SudokuLogic.solve(original);
        cells=Arrays.copyOf(original,81);
        notes=new int[81];
    }
    public boolean locked(int p){return p<0||p>=81||original[p]!=0;}
    public boolean change(int p,int n,boolean noteMode){return change(p,n,noteMode,false);}
    public boolean change(int p,int n,boolean noteMode,boolean cleanRelatedNotes){
        if(locked(p)||n<0||n>9)return false;
        if(noteMode&&n>0&&cells[p]!=0)return false;
        int[] oldCells=cells.clone(),oldNotes=notes.clone();
        if(noteMode&&n>0){notes[p]^=(1<<n);}
        else {
            cells[p]=n;notes[p]=0;
            // No quitamos candidatos en una jugada incorrecta: no debemos enseñar deducciones falsas.
            if(cleanRelatedNotes&&n>0&&n==solution[p])cleanPeerNotes(p,n);
        }
        return remember(oldCells,oldNotes);
    }
    private void cleanPeerNotes(int p,int number){
        int row=p/9,col=p%9,bit=~(1<<number);
        for(int i=0;i<81;i++) {
            if(i==p||cells[i]!=0)continue;
            if(i/9==row||i%9==col||(i/27==p/27&&(i%9)/3==col/3))notes[i]&=bit;
        }
    }
    /** Rellena las notas conforme a los números visibles y las reglas, sin revelar soluciones. */
    public int fillAutomaticNotes(boolean onlyEmpty){
        int[] oldCells=cells.clone(),oldNotes=notes.clone();int changed=0;
        for(int p=0;p<81;p++){
            if(cells[p]!=0)continue;
            if(onlyEmpty&&notes[p]!=0)continue;
            int next=SudokuLogic.candidateMask(cells,p);
            if(notes[p]!=next){notes[p]=next;changed++;}
        }
        remember(oldCells,oldNotes);return changed;
    }
    public int clearNotes(){
        int[] oldCells=cells.clone(),oldNotes=notes.clone();int changed=0;
        for(int p=0;p<81;p++)if(notes[p]!=0){notes[p]=0;changed++;}
        remember(oldCells,oldNotes);return changed;
    }
    private boolean remember(int[] oldCells,int[] oldNotes){
        if(Arrays.equals(oldCells,cells)&&Arrays.equals(oldNotes,notes))return false;
        undoHistory.push(new Move(oldCells,oldNotes,cells.clone(),notes.clone()));
        if(undoHistory.size()>MAX_UNDO)undoHistory.removeLast();
        redoHistory.clear();
        return true;
    }
    private void apply(int[] values,int[] candidateNotes){
        System.arraycopy(values,0,cells,0,81);System.arraycopy(candidateNotes,0,notes,0,81);
    }
    public boolean undo(){
        if(undoHistory.isEmpty())return false;
        Move m=undoHistory.pop();apply(m.oldCells,m.oldNotes);redoHistory.push(m);return true;
    }
    public boolean redo(){
        if(redoHistory.isEmpty())return false;
        Move m=redoHistory.pop();apply(m.newCells,m.newNotes);undoHistory.push(m);return true;
    }
    public boolean canUndo(){return !undoHistory.isEmpty();}
    public boolean canRedo(){return !redoHistory.isEmpty();}
    public boolean solved(){return SudokuLogic.isSolved(cells,solution);}
    public int filled(){int count=0;for(int x:cells)if(x!=0)count++;return count;}
    public int blanks(){return 81-filled();}
}
