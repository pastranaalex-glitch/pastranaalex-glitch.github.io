package es.bibliotecadeherramientas.sudokuvivo;

import java.util.Arrays;

/** Motor independiente de la interfaz: reglas, solución única y pistas lógicas. */
public final class SudokuLogic {
    private SudokuLogic() {}

    public static int[] parse(String text) {
        if (text == null || text.length() != 81) throw new IllegalArgumentException("Tablero inválido");
        int[] result = new int[81];
        for (int i=0; i<81; i++) {
            char ch=text.charAt(i);
            if(ch<'0'||ch>'9') throw new IllegalArgumentException("Cifra inválida");
            result[i]=ch-'0';
        }
        return result;
    }
    public static String encode(int[] values) {
        StringBuilder sb = new StringBuilder(81);
        for(int n:values) sb.append(n);
        return sb.toString();
    }
    public static boolean allowed(int[] values,int position,int number) {
        if(number<1||number>9||position<0||position>=81)return false;
        int r=position/9,c=position%9;
        for(int i=0;i<9;i++) {
            int row=r*9+i, col=i*9+c;
            if(row!=position&&values[row]==number)return false;
            if(col!=position&&values[col]==number)return false;
        }
        int r0=(r/3)*3,c0=(c/3)*3;
        for(int dr=0;dr<3;dr++)for(int dc=0;dc<3;dc++){
            int pos=(r0+dr)*9+c0+dc;
            if(pos!=position&&values[pos]==number)return false;
        }
        return true;
    }
    public static int candidateMask(int[] values,int position) {
        if(values[position]!=0)return 0;
        int mask=0;
        for(int n=1;n<=9;n++)if(allowed(values,position,n))mask|=(1<<n);
        return mask;
    }
    public static int[] solve(int[] puzzle) {
        if(puzzle==null||puzzle.length!=81||!consistent(puzzle))throw new IllegalArgumentException("El tablero contiene números incompatibles");
        int[] copy=Arrays.copyOf(puzzle,81);
        if(solveNext(copy))return copy;
        throw new IllegalArgumentException("El tablero no tiene solución");
    }
    private static boolean solveNext(int[] board) {
        int chosen=-1, options=0, minimum=10;
        for(int p=0;p<81;p++) {
            if(board[p]!=0)continue;
            int mask=candidateMask(board,p), count=Integer.bitCount(mask);
            if(count==0)return false;
            if(count<minimum) {chosen=p;options=mask;minimum=count;}
            if(count==1)break;
        }
        if(chosen<0)return true;
        for(int n=1;n<=9;n++) {
            if((options&(1<<n))==0)continue;
            board[chosen]=n;
            if(solveNext(board))return true;
            board[chosen]=0;
        }
        return false;
    }
    /** Hasta dos soluciones bastan para comprobar que un Sudoku es único. */
    public static int countSolutions(int[] puzzle,int limit) {
        if(puzzle==null||puzzle.length!=81||limit<1||!consistent(puzzle))return 0;
        return countNext(puzzle.clone(),limit);
    }
    private static boolean consistent(int[] board){
        for(int i=0;i<81;i++)if(board[i]<0||board[i]>9||(board[i]!=0&&!allowed(board,i,board[i])))return false;
        return true;
    }
    private static int countNext(int[] board,int limit){
        int best=-1,bestMask=0,min=10;
        for(int p=0;p<81;p++){
            if(board[p]!=0)continue;
            int mask=candidateMask(board,p),bits=Integer.bitCount(mask);
            if(bits==0)return 0;
            if(bits<min){best=p;bestMask=mask;min=bits;}
            if(min==1)break;
        }
        if(best==-1)return 1;
        int found=0;
        for(int n=1;n<=9;n++)if((bestMask&(1<<n))!=0){
            board[best]=n;
            found+=countNext(board,limit-found);
            board[best]=0;
            if(found>=limit)return found;
        }
        return found;
    }
    public static boolean isSolved(int[] board,int[] solution) {
        return Arrays.equals(board,solution);
    }
    public static class Hint {
        public final int position, number;
        public final String explanation;
        public final boolean isDirect;
        Hint(int p,int n,String explanation,boolean direct){this.position=p;this.number=n;this.explanation=explanation;this.isDirect=direct;}
    }
    /** Primero intenta una deducción justificable, sin leer la solución. */
    public static Hint findHint(int[] values,int[] solution) {
        for(int p=0;p<81;p++) {
            if(values[p]!=0)continue;
            int mask=candidateMask(values,p);
            if(Integer.bitCount(mask)==1) {
                int n=Integer.numberOfTrailingZeros(mask);
                if(n==solution[p])return new Hint(p,n,"La fila, la columna y el bloque descartan todos los números excepto el "+n+". Esta casilla solo tiene una posibilidad.",false);
            }
        }
        for(int group=0;group<3;group++)for(int g=0;g<9;g++)for(int n=1;n<=9;n++) {
            int found=-1,count=0;
            for(int k=0;k<9;k++) {
                int p=group==0?g*9+k:(group==1?k*9+g:(g/3*3+k/3)*9+(g%3*3+k%3));
                if(values[p]==0&&(candidateMask(values,p)&(1<<n))!=0) {count++;found=p;}
            }
            if(count==1&&found>=0&&solution[found]==n) {
                String name=group==0?"fila "+(g+1):group==1?"columna "+(g+1):"bloque "+(g+1);
                return new Hint(found,n,"En la "+name+", el "+n+" solo puede colocarse en una casilla. Las demás posiciones quedan descartadas.",false);
            }
        }
        for(int p=0;p<81;p++)if(values[p]==0)
            return new Hint(p,solution[p],"Este paso requiere una técnica más avanzada. Puedes intentar resolverlo con tus notas o pedir que se revele este número.",true);
        return null;
    }
}
