package es.bibliotecadeherramientas.sudokuvivo;

import android.graphics.Color;

/** Paletas profesionales; la persona escoge sin perder contraste. */
public final class ThemePalette {
    public final String name;
    public final int bg,surface,board,ink,muted,given,entered,grid,major,accent,selection,related,same,note,error,border,button;
    private ThemePalette(String name,String bg,String surface,String board,String ink,String muted,String given,String entered,String grid,String major,String accent,String selection,String related,String same,String note,String error,String border,String button) {
        this.name=name;
        this.bg=c(bg);this.surface=c(surface);this.board=c(board);this.ink=c(ink);this.muted=c(muted);this.given=c(given);this.entered=c(entered);this.grid=c(grid);this.major=c(major);this.accent=c(accent);this.selection=c(selection);this.related=c(related);this.same=c(same);this.note=c(note);this.error=c(error);this.border=c(border);this.button=c(button);
    }
    private static int c(String h){return Color.parseColor(h);}
    public static final ThemePalette[] ALL={
        new ThemePalette("Clásico","#F4F6F8","#FFFFFF","#FFFFFF","#253348","#647486","#26364A","#235F97","#C8D2DC","#536579","#2C638F","#B9D5ED","#EDF3F8","#DCE9F4","#527496","#B63737","#DAE1E8","#E9EFF5"),
        new ThemePalette("Nocturno","#121B27","#1E2A39","#202D3E","#E9F0F5","#AABBC9","#F3F5F7","#E4C98B","#5F758C","#B7C7D4","#D8BA7A","#38536A","#293B4F","#42536A","#C9DAE8","#FF9C9C","#3F5063","#304358"),
        new ThemePalette("Océano","#E8F2F6","#F7FCFD","#FFFFFF","#1E3D4D","#5D7987","#25445A","#006A84","#BDCED3","#557C88","#087E91","#B6DFE4","#E9F4F6","#D1EBEC","#31778A","#BC3434","#CADFE5","#E1F1F4"),
        new ThemePalette("Bosque","#EEF3EC","#FAFCF8","#FFFFFF","#273D31","#657768","#23392C","#346A48","#CFDBCD","#698371","#3F7653","#C6DECA","#EDF4ED","#DDEADC","#53795B","#A72F3A","#D6E1D5","#E5F0E5"),
        new ThemePalette("Vino","#F6F0F2","#FFFCFD","#FFFFFF","#482B3B","#836D79","#3D2E39","#8A425D","#DFCCD5","#916E7F","#8A425D","#E9CAD6","#F6EDF1","#F0DAE3","#92657B","#B3263F","#EADBE0","#F4E6EB"),
        new ThemePalette("Marfil","#F2EEE4","#FFFCF5","#FFFEFA","#41382E","#756B5C","#3E362D","#80603A","#DCD4C4","#786B5A","#8E6F42","#E7D8BD","#F4EFE4","#EDE1CF","#776149","#AC3434","#E3D8C7","#F3E9D7")
    };
    public static ThemePalette of(int idx){return ALL[Math.max(0,Math.min(ALL.length-1,idx))];}
}
